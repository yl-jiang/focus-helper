'use strict';

const params = new URLSearchParams(location.search);
const site = params.get('site');
const siteLine = document.getElementById('site-line');
if (site) {
  siteLine.textContent = `今日额度已用完的网站：${site}`;
  siteLine.hidden = false;
}

document.getElementById('close-tab').addEventListener('click', async () => {
  const status = document.getElementById('status');
  try {
    const tab = await chrome.tabs.getCurrent();
    if (tab && tab.id !== undefined) {
      await chrome.tabs.remove(tab.id);
      return;
    }
    window.close();
  } catch (err) {
    status.textContent = '无法自动关闭，请手动关闭此标签页。';
  }
});
