'use strict';

// 专注助手：本地浏览活动统计与聚合（classic script，由 background 顶部 importScripts 加载）。
// 唯一顶层名 FocusAnalytics；复用 background 同一作用域的 localDateString，不重复声明工具函数。
// 所有统计数值只来自本地日志，不与 LLM 结果混算。
const FocusAnalytics = (() => {
  // 按本地日历日分桶：activity:${date} / hourly:${date}，activityDates 是已落盘日期的排序索引
  const STORAGE_VERSION = 2;
  const LEGACY_KEYS = ['activity', 'hourlyByDate'];
  const TITLE_MAX = 200;
  // 活动明细分页固定页大小
  const PAGE_SIZE = 20;
  // 近期时段流水：只留近 3 天、最多 1000 段，相邻同域同标题且间隔 ≤1s 合并
  const SEGMENT_KEEP_DAYS = 3;
  const SEGMENT_MAX = 1000;
  const SEGMENT_MERGE_GAP_MS = 1000;

  // 统计范围：month 为本月 1 日至今，all 为最早记录至今，其余为近 N 天
  const RANGE_DAYS = { today: 1, week: 7, month30: 30, '3months': 90, '6months': 180, year: 365 };
  const RANGE_NAMES = new Set([...Object.keys(RANGE_DAYS), 'month', 'all']);
  // 数字入参向后兼容旧调用（popup 仍传 rangeDays: 1）
  const LEGACY_RANGE = { 1: 'today', 7: 'week', 30: 'month30' };

  // 固定分类词表（与 LLM 提示共用）
  const CATEGORIES = ['学习', '工作', '开发', '社交', '资讯', '搜索', '购物', '娱乐', '工具', '其他'];

  // 常见域名本地分类映射：先精确匹配，再逐级去掉子域查找；未知归“其他”
  const DOMAIN_CATEGORY = {
    'bilibili.com': '娱乐',
    'youtube.com': '娱乐',
    'douyin.com': '娱乐',
    'tiktok.com': '娱乐',
    'iqiyi.com': '娱乐',
    'youku.com': '娱乐',
    'twitch.tv': '娱乐',
    'github.com': '开发',
    'gitlab.com': '开发',
    'stackoverflow.com': '开发',
    'developer.mozilla.org': '开发',
    'juejin.cn': '开发',
    'csdn.net': '开发',
    'leetcode.com': '学习',
    'leetcode.cn': '学习',
    'coursera.org': '学习',
    'khanacademy.org': '学习',
    'wikipedia.org': '学习',
    'zhihu.com': '资讯',
    'weibo.com': '社交',
    'twitter.com': '社交',
    'x.com': '社交',
    'facebook.com': '社交',
    'instagram.com': '社交',
    'reddit.com': '社交',
    'linkedin.com': '工作',
    'gmail.com': '工作',
    'outlook.com': '工作',
    'office.com': '工作',
    'feishu.cn': '工作',
    'taobao.com': '购物',
    'jd.com': '购物',
    'tmall.com': '购物',
    'pinduoduo.com': '购物',
    'amazon.com': '购物',
    'amazon.cn': '购物',
    'baidu.com': '搜索',
    'google.com': '搜索',
    'bing.com': '搜索',
    'duckduckgo.com': '搜索',
    'sogou.com': '搜索',
  };

  function categoryOf(domain) {
    let d = typeof domain === 'string' ? domain.toLowerCase() : '';
    while (d) {
      if (Object.prototype.hasOwnProperty.call(DOMAIN_CATEGORY, d)) return DOMAIN_CATEGORY[d];
      const i = d.indexOf('.');
      if (i < 0) break;
      d = d.slice(i + 1);
    }
    return '其他';
  }

  // LLM 分类覆盖：键按「域名|标题」逐条记忆，同一域名不同标题可以不同类。
  // 未覆盖的条目仍走 categoryOf 硬规则，所以覆盖只增补、不改变未分析过的历史。
  const OVERRIDE_KEY = 'categoryOverrides';
  const ANALYSIS_KEY = 'latestAnalysis';

  function activityCategoryKey(domain, title) {
    return `${domain}|${title}`;
  }

  function categoryOfActivity(domain, title, overrides) {
    const key = activityCategoryKey(domain, title);
    if (overrides && typeof overrides === 'object' && Object.prototype.hasOwnProperty.call(overrides, key)) {
      const category = overrides[key];
      if (CATEGORIES.includes(category)) return category;
    }
    return categoryOf(domain);
  }

  // 存储里的映射一律逐条按词表校验：分类名不合法的条目直接丢弃，不参与任何统计。
  // 返回普通对象而非 Map：调用方（llm.js 的分析合并）按对象展开累积，Map 会被展开成空对象。
  function normalizeOverrides(source) {
    const out = {};
    if (!source || typeof source !== 'object' || Array.isArray(source)) return out;
    for (const [key, value] of Object.entries(source)) {
      if (typeof value === 'string' && CATEGORIES.includes(value)) out[key] = value;
    }
    return out;
  }

  // 空对象是「用户已清空覆盖」的权威值，此时不回退到旧分析结果；
  // 只有该键缺失（旧版本数据）才用最近一次分析的 classifiedActivities 推导，且绝不回写存储。
  async function loadCategoryOverrides() {
    const raw = await chrome.storage.local.get([OVERRIDE_KEY, ANALYSIS_KEY]);
    if (raw[OVERRIDE_KEY] && typeof raw[OVERRIDE_KEY] === 'object' && !Array.isArray(raw[OVERRIDE_KEY])) {
      return normalizeOverrides(raw[OVERRIDE_KEY]);
    }
    const analysis = raw[ANALYSIS_KEY];
    const legacy = analysis && typeof analysis === 'object' && Array.isArray(analysis.classifiedActivities)
      ? analysis.classifiedActivities : [];
    const derived = {};
    for (const a of legacy) {
      if (!a || typeof a !== 'object' || typeof a.domain !== 'string') continue;
      if (typeof a.category !== 'string') continue;
      derived[activityCategoryKey(a.domain, a.title)] = a.category;
    }
    return normalizeOverrides(derived);
  }

  // 标题缺失用 domain 兜底，入库截断
  function normalizeTitle(title, domain) {
    const t = typeof title === 'string' && title.trim() ? title.trim() : domain;
    return t.length > TITLE_MAX ? t.slice(0, TITLE_MAX) : t;
  }

  function activityKey(date) {
    return `activity:${date}`;
  }

  function hourlyKey(date) {
    return `hourly:${date}`;
  }

  function isDateString(value) {
    if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
    const [y, m, d] = value.split('-').map(Number);
    const dt = new Date(y, m - 1, d);
    return dt.getFullYear() === y && dt.getMonth() === m - 1 && dt.getDate() === d;
  }

  function sanitizeIndex(list) {
    if (!Array.isArray(list)) return [];
    return [...new Set(list.filter(isDateString))].sort();
  }

  // 保证日分桶就绪并返回排好序的日期索引；调用方必须已持有 LOCK_NAME，本函数不再加锁。
  // 迁移中途失败时旧键仍在，重跑按 (date,domain,title) 覆盖写入，因此重复迁移不会翻倍。
  async function ensureDailyStorage() {
    const meta = await chrome.storage.local.get(['activityStorageVersion', 'activityDates']);
    if (meta.activityStorageVersion === STORAGE_VERSION) return sanitizeIndex(meta.activityDates);

    const legacy = await chrome.storage.local.get(LEGACY_KEYS);
    const legacyGroups = Array.isArray(legacy.activity) ? legacy.activity : [];
    const legacyHourly = legacy.hourlyByDate && typeof legacy.hourlyByDate === 'object' &&
      !Array.isArray(legacy.hourlyByDate) ? legacy.hourlyByDate : {};

    const dates = new Set(sanitizeIndex(meta.activityDates));
    const buckets = new Map();
    for (const g of legacyGroups) {
      if (!g || !isDateString(g.date) || typeof g.domain !== 'string') continue;
      const bucket = buckets.get(g.date) || new Map();
      bucket.set(`${g.domain}|${g.title}`, {
        date: g.date,
        domain: g.domain,
        title: g.title,
        durationMs: g.durationMs || 0,
        firstTs: g.firstTs,
        lastTs: g.lastTs,
      });
      buckets.set(g.date, bucket);
      dates.add(g.date);
    }
    for (const date of Object.keys(legacyHourly)) {
      if (isDateString(date)) dates.add(date);
    }

    // 上次中断可能已写入日分桶但没写索引，这些日期同样要读出来合并
    const dayKeys = [];
    for (const date of dates) dayKeys.push(activityKey(date), hourlyKey(date));
    const stored = dayKeys.length > 0 ? await chrome.storage.local.get(dayKeys) : {};

    const writes = {};
    for (const date of dates) {
      const bucket = buckets.get(date) || new Map();
      const storedGroups = stored[activityKey(date)];
      if (Array.isArray(storedGroups)) {
        for (const g of storedGroups) {
          if (!g || typeof g.domain !== 'string') continue;
          const key = `${g.domain}|${g.title}`;
          if (!bucket.has(key)) bucket.set(key, g);
        }
      }
      if (bucket.size > 0) writes[activityKey(date)] = [...bucket.values()];
      // 旧 hourlyByDate 是权威值：同一天已写过分桶也用旧值覆盖，避免重跑时相加
      const slots = legacyHourly[date] !== undefined ? legacyHourly[date] : stored[hourlyKey(date)];
      if (Array.isArray(slots)) writes[hourlyKey(date)] = slots;
    }

    // 顺序不可换：日分桶全部落盘 → 版本标记与索引 → 最后删旧键。
    // 版本标记前失败会保留旧数据，下次迁移可安全重试。
    if (Object.keys(writes).length > 0) await chrome.storage.local.set(writes);
    const index = [...dates].sort();
    await chrome.storage.local.set({ activityDates: index, activityStorageVersion: STORAGE_VERSION });
    await chrome.storage.local.remove(LEGACY_KEYS);
    return index;
  }

  // 近期时段只留近 SEGMENT_KEEP_DAYS 天，超出 SEGMENT_MAX 按 endTs 淘汰最旧
  function pruneSegments(segments, now) {
    const cutoff = new Date(now);
    cutoff.setHours(0, 0, 0, 0);
    cutoff.setDate(cutoff.getDate() - (SEGMENT_KEEP_DAYS - 1));
    const minTs = cutoff.getTime();
    let arr = segments.filter((s) => s && typeof s.endTs === 'number' && s.endTs >= minTs);
    if (arr.length > SEGMENT_MAX) {
      arr.sort((a, b) => a.endTs - b.endTs);
      arr = arr.slice(arr.length - SEGMENT_MAX);
    }
    segments.length = 0;
    segments.push(...arr);
  }

  // 同日相邻同域同标题且间隔 ≤1s 的时段合并：durationMs 累加，startTs 取最早，endTs 取最新
  function mergeSegment(list, seg) {
    const last = list[list.length - 1];
    if (last && last.domain === seg.domain && last.title === seg.title &&
        typeof last.startTs === 'number' && localDateString(last.startTs) === localDateString(seg.startTs) &&
        typeof last.endTs === 'number' && seg.startTs >= last.endTs &&
        seg.startTs - last.endTs <= SEGMENT_MERGE_GAP_MS) {
      last.durationMs += seg.durationMs;
      last.startTs = Math.min(last.startTs, seg.startTs);
      last.endTs = Math.max(last.endTs, seg.endTs);
    } else {
      list.push(seg);
    }
  }

  // 按 effectiveStart→now 跨小时分配整数毫秒，尾差归结束小时，保证各小时合计=elapsedMs
  function buildHourlyDelta(effectiveStart, now, elapsedMs) {
    if (!Number.isFinite(effectiveStart) || effectiveStart >= now) return null;
    const byDate = new Map();
    let cursor = effectiveStart;
    let assigned = 0;
    while (cursor < now) {
      const d = new Date(cursor);
      const next = new Date(d);
      next.setHours(d.getHours() + 1, 0, 0, 0);
      const end = Math.min(now, next.getTime());
      const ms = end - cursor;
      const date = localDateString(cursor);
      const slots = byDate.get(date) || new Array(24).fill(0);
      slots[d.getHours()] += ms;
      byDate.set(date, slots);
      assigned += ms;
      cursor = end;
    }
    const tail = elapsedMs - assigned;
    if (tail !== 0) {
      const endD = new Date(now);
      const date = localDateString(now);
      const slots = byDate.get(date) || new Array(24).fill(0);
      slots[endD.getHours()] += tail;
      byDate.set(date, slots);
    }
    return byDate;
  }

  // 累加一段活动：只读写当天分桶 + 日期索引 + 近期时段流水，不再读写整份活动/小时历史。
  // 调用方必须已持有 LOCK_NAME（tick 内部），本函数不再加锁、不可重入调用。
  async function recordSegment(segment, elapsedMs, now, effectiveStart = segment.startTs) {
    if (!segment || typeof segment.domain !== 'string' || elapsedMs <= 0) return;
    const index = await ensureDailyStorage();

    const domain = segment.domain;
    const title = normalizeTitle(segment.title, domain);
    const date = localDateString(now);

    // 跨小时分配实际只会落在今天（tick 已把 effectiveStart 截到今日 0 点），
    // 这里仍按 delta 出现的日期读写，保持跨午夜行为不变
    const delta = buildHourlyDelta(effectiveStart, now, elapsedMs);
    const hourlyDates = delta ? [...delta.keys()] : [];
    const readKeys = [activityKey(date), 'recentSegments', 'activityTruncated'];
    for (const d of hourlyDates) readKeys.push(hourlyKey(d));
    const raw = await chrome.storage.local.get(readKeys);

    // 1) 当天 (date,domain,title) 聚合
    const groups = Array.isArray(raw[activityKey(date)]) ? raw[activityKey(date)] : [];
    const existing = groups.find((g) => g && g.domain === domain && g.title === title);
    if (existing) {
      existing.durationMs += elapsedMs;
      existing.lastTs = now;
    } else {
      groups.push({
        date,
        domain,
        title,
        durationMs: elapsedMs,
        firstTs: typeof segment.startTs === 'number' ? segment.startTs : now,
        lastTs: now,
      });
    }
    const writes = { [activityKey(date)]: groups };

    // 2) 当天小时槽：跨小时分配，旧记录无该字段也不伪造
    if (delta) {
      for (const [d, slots] of delta) {
        const cur = Array.isArray(raw[hourlyKey(d)]) ? raw[hourlyKey(d)].slice() : new Array(24).fill(0);
        for (let h = 0; h < 24; h++) cur[h] = (cur[h] || 0) + slots[h];
        writes[hourlyKey(d)] = cur;
      }
    }

    // 3) 近期时段流水（相邻合并 + 清理）；裁剪标志不再产生，但必须原样保留
    const segments = Array.isArray(raw.recentSegments) ? raw.recentSegments : [];
    mergeSegment(segments, {
      domain,
      title,
      startTs: effectiveStart,
      endTs: now,
      durationMs: elapsedMs,
    });
    pruneSegments(segments, now);
    writes.recentSegments = segments;
    if (raw.activityTruncated === true) writes.activityTruncated = true;

    // 4) 索引已含当天时不重复写
    const dates = new Set(index);
    let indexChanged = false;
    for (const d of [date, ...hourlyDates]) {
      if (!dates.has(d)) {
        dates.add(d);
        indexChanged = true;
      }
    }
    if (indexChanged) writes.activityDates = [...dates].sort();

    await chrome.storage.local.set(writes);
  }

  // 今日往前 days 天的本地日期字符串（旧→新）
  function lastNDates(days, now) {
    const base = new Date(now);
    base.setHours(0, 0, 0, 0);
    const out = [];
    for (let i = days - 1; i >= 0; i--) {
      const d = new Date(base);
      d.setDate(base.getDate() - i);
      out.push(localDateString(d.getTime()));
    }
    return out;
  }

  function dateStartMs(dateStr) {
    const [y, m, d] = dateStr.split('-').map(Number);
    return new Date(y, m - 1, d).getTime();
  }

  // 逐日走 Date.setDate 生成本地日历日序列，不用固定毫秒推算（跨夏令时也不偏日）
  function dateSeries(startDate, endDate) {
    const out = [];
    const endMs = dateStartMs(endDate);
    const cur = new Date(dateStartMs(startDate));
    while (cur.getTime() <= endMs) {
      out.push(localDateString(cur.getTime()));
      cur.setDate(cur.getDate() + 1);
    }
    return out;
  }

  function normalizeRange(rangeInput) {
    if (typeof rangeInput === 'string') {
      const key = rangeInput.trim().toLowerCase();
      return RANGE_NAMES.has(key) ? key : 'today';
    }
    if (Object.prototype.hasOwnProperty.call(LEGACY_RANGE, rangeInput)) return LEGACY_RANGE[rangeInput];
    return 'today';
  }

  function rangeDates(range, now, dataStartDate) {
    const today = new Date(now);
    today.setHours(0, 0, 0, 0);
    const endDate = localDateString(today.getTime());
    const start = new Date(today);
    if (range === 'month') {
      start.setDate(1);
    } else if (range === 'all') {
      // 「所有」必须覆盖现存最早记录：合法早期日期（如 1970/2010）是真实历史，不设年代上限
      if (dataStartDate && dataStartDate <= endDate) return dateSeries(dataStartDate, endDate);
      return [endDate];
    } else {
      start.setDate(today.getDate() - (RANGE_DAYS[range] - 1));
    }
    return dateSeries(localDateString(start.getTime()), endDate);
  }

  // 本地统计。range 支持 today/week/month30/month/3months/6months/year/all，
  // 数字 1/7/30 映射为 today/week/month30；summaryOnly 时不返回 activities/recentSegments/hourly 大列表。
  async function getDashboard(rangeInput, options = {}, now = Date.now()) {
    const summaryOnly = Boolean(options && options.summaryOnly);
    // 只有显式 false 才不下发 activities；统计仍按范围内全部组计算
    const includeActivities = !summaryOnly && !(options && options.includeActivities === false);
    const index = await ensureDailyStorage();
    const dataStartDate = index.length > 0 ? index[0] : null;
    const range = normalizeRange(rangeInput);
    const dates = rangeDates(range, now, dataStartDate);
    const endDate = dates[dates.length - 1];
    const overrides = await loadCategoryOverrides();

    const readKeys = dates.map(activityKey);
    if (!summaryOnly) for (const date of dates) readKeys.push(hourlyKey(date));
    readKeys.push('recentSegments', 'activityTruncated');
    const raw = await chrome.storage.local.get(readKeys);

    const groups = [];
    for (const date of dates) {
      const stored = raw[activityKey(date)];
      if (Array.isArray(stored)) groups.push(...stored);
    }

    let total = 0;
    const byDomain = new Map();
    const byCategory = new Map();
    const byDate = new Map(dates.map((d) => [d, 0]));
    const llmMatchedKeys = new Set();
    for (const g of groups) {
      const d = g.durationMs || 0;
      total += d;
      byDomain.set(g.domain, (byDomain.get(g.domain) || 0) + d);
      const key = activityCategoryKey(g.domain, g.title);
      if (Object.prototype.hasOwnProperty.call(overrides, key) && CATEGORIES.includes(overrides[key])) llmMatchedKeys.add(key);
      const category = categoryOfActivity(g.domain, g.title, overrides);
      byCategory.set(category, (byCategory.get(category) || 0) + d);
      if (byDate.has(g.date)) byDate.set(g.date, byDate.get(g.date) + d);
    }

    // 域名级分类保持硬规则：同一域名下不同标题可能落在不同类
    const domainStats = [...byDomain.entries()]
      .map(([domain, durationMs]) => ({ domain, category: categoryOf(domain), durationMs }))
      .sort((a, b) => b.durationMs - a.durationMs);
    const categoryStats = CATEGORIES
      .map((category) => ({ category, durationMs: byCategory.get(category) || 0 }))
      .sort((a, b) => b.durationMs - a.durationMs);
    const dailyStats = dates.map((date) => ({ date, durationMs: byDate.get(date) || 0 }));

    // 24 小时槽：范围内每天 24 个整数毫秒槽；旧记录无该字段时不伪造
    let hourly = [];
    let hourlyAvailable = false;
    let hourlyCoveredDays = 0;
    if (!summaryOnly) {
      hourly = dates.map((date) => {
        const stored = Array.isArray(raw[hourlyKey(date)]) ? raw[hourlyKey(date)] : [];
        const slots = new Array(24).fill(0);
        for (let h = 0; h < 24; h++) slots[h] = Math.max(0, Math.round(stored[h] || 0));
        const totalMs = slots.reduce((a, b) => a + b, 0);
        return { date, slots, totalMs };
      });
      hourlyCoveredDays = hourly.filter((h) => h.totalMs > 0).length;
      hourlyAvailable = hourlyCoveredDays > 0;
    }

    // 活动明细：范围内全部组，按 lastTs 降序；includeActivities=false 时由 getActivityPage 分页取
    const activities = includeActivities ? groups
      .slice()
      .sort((a, b) => (b.lastTs || 0) - (a.lastTs || 0))
      .map((g) => ({
        domain: g.domain,
        title: g.title,
        durationMs: g.durationMs,
        firstTs: g.firstTs,
        lastTs: g.lastTs,
        category: categoryOfActivity(g.domain, g.title, overrides),
      })) : [];

    // 近期时段流水：至少覆盖近 3 天，避免「今日」范围裁掉时间线；按 startTs 升序
    let recentSegments = [];
    if (!summaryOnly) {
      const segStartDate = dates.length >= SEGMENT_KEEP_DAYS ? dates[0] : lastNDates(SEGMENT_KEEP_DAYS, now)[0];
      const rangeStart = dateStartMs(segStartDate);
      const rangeEnd = dateStartMs(endDate) + 24 * 3600 * 1000;
      recentSegments = (Array.isArray(raw.recentSegments) ? raw.recentSegments : [])
        .filter((s) => s && typeof s.startTs === 'number' && typeof s.endTs === 'number' &&
          s.endTs >= rangeStart && s.startTs < rangeEnd)
        .slice()
        .sort((a, b) => a.startTs - b.startTs)
        .map((s) => ({ domain: s.domain, title: s.title, startTs: s.startTs, endTs: s.endTs, durationMs: s.durationMs }));
    }

    return {
      range,
      startDate: dates[0],
      endDate,
      dataStartDate,
      rangeDays: dates.length,
      totalDurationMs: total,
      domainStats,
      categoryStats,
      dailyStats,
      activities,
      hourly,
      hourlyAvailable,
      hourlyCoveredDays,
      recentSegments,
      categories: CATEGORIES.slice(),
      activityTruncated: raw.activityTruncated === true,
      llmCategoryCount: llmMatchedKeys.size,
    };
  }

  // 活动明细分页：范围与 getDashboard 一致，只读 activity:${date}，
  // 筛选与排序全部在后台完成，前端每页只拿 PAGE_SIZE 条（历史不截断）
  async function getActivityPage(rangeInput, options = {}, now = Date.now()) {
    const opts = options && typeof options === 'object' ? options : {};
    const index = await ensureDailyStorage();
    const dataStartDate = index.length > 0 ? index[0] : null;
    const range = normalizeRange(rangeInput);
    const dates = rangeDates(range, now, dataStartDate);
    const endDate = dates[dates.length - 1];
    const overrides = await loadCategoryOverrides();
    const raw = await chrome.storage.local.get(dates.map(activityKey));

    const search = typeof opts.search === 'string' ? opts.search.trim().toLowerCase() : '';
    const domain = typeof opts.domain === 'string' ? opts.domain.trim() : '';
    // 非法筛选值安全回退为「全部」
    const category = CATEGORIES.includes(opts.category) ? opts.category : '';
    const sort = opts.sort === 'duration' ? 'duration' : 'recent';

    const filtered = [];
    for (const date of dates) {
      const groups = raw[activityKey(date)];
      if (!Array.isArray(groups)) continue;
      for (const g of groups) {
        if (!g || typeof g.domain !== 'string') continue;
        if (domain && g.domain !== domain) continue;
        const cat = categoryOfActivity(g.domain, g.title, overrides);
        if (category && cat !== category) continue;
        if (search) {
          const title = typeof g.title === 'string' ? g.title : '';
          if (!title.toLowerCase().includes(search) && !g.domain.toLowerCase().includes(search)) continue;
        }
        filtered.push({
          domain: g.domain,
          title: g.title,
          durationMs: g.durationMs || 0,
          firstTs: g.firstTs,
          lastTs: g.lastTs,
          category: cat,
        });
      }
    }

    // 确定性顺序：同值时依次比较最近时间、域名、标题
    const byRecent = (a, b) => (b.lastTs || 0) - (a.lastTs || 0);
    const filteredSorted = filtered.sort((a, b) => {
      if (sort === 'duration') {
        const diff = b.durationMs - a.durationMs;
        if (diff !== 0) return diff;
      }
      const recent = byRecent(a, b);
      if (recent !== 0) return recent;
      if (a.domain !== b.domain) return a.domain < b.domain ? -1 : 1;
      if (a.title !== b.title) return a.title < b.title ? -1 : 1;
      return 0;
    });

    const total = filteredSorted.length;
    const pages = Math.max(1, Math.ceil(total / PAGE_SIZE));
    const requested = Number(opts.page);
    const page = Math.min(Number.isFinite(requested) && requested >= 1 ? Math.floor(requested) : 1, pages);

    return {
      range,
      startDate: dates[0],
      endDate,
      dataStartDate,
      rangeDays: dates.length,
      total,
      page,
      pages,
      pageSize: PAGE_SIZE,
      activities: filteredSorted.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE),
    };
  }

  // 聚合输入：近 days 天按 (domain,title) 合并，耗时降序取前 limit，生成本地唯一 id a1…aN
  async function topActivities(days, limit, now = Date.now()) {
    await ensureDailyStorage();
    const dates = lastNDates(days, now);
    const raw = await chrome.storage.local.get(dates.map(activityKey));
    const merged = new Map();
    for (const date of dates) {
      const groups = raw[activityKey(date)];
      if (!Array.isArray(groups)) continue;
      for (const g of groups) {
        if (!g || typeof g.domain !== 'string') continue;
        const key = activityCategoryKey(g.domain, g.title);
        const cur = merged.get(key) || { domain: g.domain, title: g.title, durationMs: 0, lastTs: 0 };
        cur.durationMs += g.durationMs || 0;
        cur.lastTs = Math.max(cur.lastTs, g.lastTs || 0);
        merged.set(key, cur);
      }
    }
    return [...merged.values()]
      .sort((a, b) => b.durationMs - a.durationMs)
      .slice(0, limit)
      .map((a, i) => ({ id: `a${i + 1}`, domain: a.domain, title: a.title, durationMs: a.durationMs, lastTs: a.lastTs }));
  }

  // 清空全部活动日分桶与旧键，保留规则、LLM 配置等其他设置（调用方必须已持有 LOCK_NAME）
  // 分类覆盖随历史一起清空：写入空对象而非删除键，避免下次读到旧分析结果又“复活”覆盖
  async function clearAll() {
    const index = await ensureDailyStorage();
    const keys = LEGACY_KEYS.slice();
    for (const date of index) keys.push(activityKey(date), hourlyKey(date));
    await chrome.storage.local.remove(keys);
    await chrome.storage.local.set({
      activityDates: [],
      activityStorageVersion: STORAGE_VERSION,
      recentSegments: [],
      activityTruncated: false,
      [OVERRIDE_KEY]: {},
    });
  }

  return {
    SEGMENT_KEEP_DAYS, SEGMENT_MAX, PAGE_SIZE, CATEGORIES,
    categoryOf, activityCategoryKey, categoryOfActivity, loadCategoryOverrides,
    recordSegment, getDashboard, getActivityPage, topActivities, clearAll,
  };
})();
