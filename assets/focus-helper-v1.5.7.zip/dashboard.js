'use strict';

const els = {
  navOverview: document.getElementById('nav-overview'),
  navActivities: document.getElementById('nav-activities'),
  navAnalysis: document.getElementById('nav-analysis'),
  viewOverview: document.getElementById('view-overview'),
  viewActivities: document.getElementById('view-activities'),
  viewAnalysis: document.getElementById('view-analysis'),
  rangeSelect: document.getElementById('range-select'),
  rangeNote: document.getElementById('range-note'),
  clearBtn: document.getElementById('clear-history-btn'),
  statusEl: document.getElementById('page-status'),
  loadingEl: document.getElementById('page-loading'),
  emptyEl: document.getElementById('page-empty'),
  summaryBand: document.getElementById('summary-band'),
  statTotal: document.getElementById('stat-total'),
  statSites: document.getElementById('stat-sites'),
  statActiveDays: document.getElementById('stat-active-days'),
  statPeakHour: document.getElementById('stat-peak-hour'),
  truncateNotes: document.querySelectorAll('[data-truncate-note], #truncate-note'),
  dataGrid: document.getElementById('data-grid'),
  categoryTitle: document.getElementById('h-categories'),
  categoryBars: document.getElementById('category-bars'),
  domainBars: document.getElementById('domain-bars'),
  domainCount: document.getElementById('domain-count'),
  dailyBars: document.getElementById('daily-bars'),
  dailyYAxis: document.getElementById('daily-y-axis'),
  dailyTitle: document.getElementById('h-daily'),
  dailyXTitle: document.getElementById('daily-x-title'),
  hourlyMeta: document.getElementById('hourly-meta'),
  hourlyChart: document.getElementById('hourly-chart'),
  hourlyX: document.getElementById('hourly-x'),
  hourlyEmpty: document.getElementById('hourly-empty'),
  timelineLegend: document.getElementById('timeline-legend'),
  timelineChart: document.getElementById('timeline-chart'),
  timelineEmpty: document.getElementById('timeline-empty'),
  activityTotal: document.getElementById('activity-total'),
  activitySummary: document.getElementById('activity-summary'),
  activityTrend: document.getElementById('activity-trend'),
  activityCategories: document.getElementById('activity-categories'),
  activityDays: document.getElementById('activity-days'),
  detailSearch: document.getElementById('detail-search'),
  detailDomain: document.getElementById('detail-domain'),
  detailCategory: document.getElementById('detail-category'),
  detailSort: document.getElementById('detail-sort'),
  detailCount: document.getElementById('detail-count'),
  detailTbody: document.getElementById('detail-tbody'),
  detailEmpty: document.getElementById('detail-empty'),
  prevPage: document.getElementById('prev-page'),
  nextPage: document.getElementById('next-page'),
  pageInfo: document.getElementById('page-info'),
  analyzeBtn: document.getElementById('analyze-btn'),
  analysisResult: document.getElementById('analysis-result'),
  aiOrbitNodes: document.getElementById('ai-orbit-nodes'),
  aiEvidenceContent: document.getElementById('ai-evidence-content'),
  llmForm: document.getElementById('llm-form'),
  baseUrlInput: document.getElementById('llm-base-url'),
  modelNameInput: document.getElementById('llm-model-name'),
  apiKeyInput: document.getElementById('llm-api-key'),
  toggleKeyBtn: document.getElementById('llm-toggle-key'),
  saveBtn: document.getElementById('llm-save-btn'),
  testBtn: document.getElementById('llm-test-btn'),
  clearKeyBtn: document.getElementById('llm-clear-key-btn'),
  confirmDialog: document.getElementById('confirm-dialog'),
};

const DAY_MS = 24 * 3600 * 1000;
// 统计范围与后台契约保持一致，select 的 value 即发送的 range
const RANGES = ['today', 'week', 'month30', 'month', '3months', '6months', 'year', 'all'];
const DEFAULT_RANGE = 'week';
// 趋势聚合阈值：超过 31 天按周，超过 180 天按月
const DAY_AGGREGATE_LIMIT = 31;
const WEEK_AGGREGATE_LIMIT_DAYS = 180;
// 域名色板仅用于时间线
const TIMELINE_PALETTE = ['#4f46e5', '#0e7490', '#b45309', '#047857', '#be185d', '#6d28d9', '#1d4ed8', '#a16207', '#0f766e', '#7c2d12'];

const initialParams = new URLSearchParams(location.search);
const initialView = ['overview', 'activities', 'analysis'].includes(initialParams.get('view')) ? initialParams.get('view') : 'overview';
const initialRange = RANGES.includes(initialParams.get('range')) ? initialParams.get('range') : DEFAULT_RANGE;
const initialPage = Number(initialParams.get('page'));
const ui = {
  view: initialView,
  range: initialRange,
  seq: 0,
  detailSeq: 0,
  detail: {
    search: initialParams.get('search') || '',
    domain: initialParams.get('domain') || '',
    category: initialParams.get('category') || '',
    sort: initialParams.get('sort') === 'duration' ? 'duration' : 'recent',
    page: Number.isInteger(initialPage) && initialPage > 0 ? initialPage : 1,
  },
};

function setStatus(message, isError) {
  els.statusEl.textContent = message;
  els.statusEl.classList.toggle('error', Boolean(isError));
}

// 与 popup 一致：0 显示 0 分钟；已用向下、剩余向上；支持小时与不足 1 分钟
function formatDuration(ms, direction) {
  if (ms <= 0) return '0 分钟';
  const totalMin = direction === 'up' ? Math.ceil(ms / 60000) : Math.floor(ms / 60000);
  if (totalMin < 1) return '不足 1 分钟';
  const hours = Math.floor(totalMin / 60);
  const minutes = totalMin % 60;
  if (hours > 0) return minutes > 0 ? `${hours} 小时 ${minutes} 分钟` : `${hours} 小时`;
  return `${totalMin} 分钟`;
}

function formatDateTime(ts) {
  const d = new Date(ts);
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
}

function formatTime(ts) {
  const d = new Date(ts);
  const p = (n) => String(n).padStart(2, '0');
  return `${p(d.getHours())}:${p(d.getMinutes())}`;
}

function formatDay(dateStr) {
  return dateStr.slice(5);
}

function localDateStringOf(ts) {
  const d = new Date(ts);
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

function dateStartMs(dateStr) {
  const [y, m, d] = dateStr.split('-').map(Number);
  return new Date(y, m - 1, d).getTime();
}

// ---------- 视图切换 ----------

const VIEWS = {
  overview: { nav: 'navOverview', section: 'viewOverview' },
  activities: { nav: 'navActivities', section: 'viewActivities' },
  analysis: { nav: 'navAnalysis', section: 'viewAnalysis' },
};

function syncUrl() {
  const params = new URLSearchParams();
  if (ui.view !== 'overview') params.set('view', ui.view);
  if (ui.range !== DEFAULT_RANGE) params.set('range', ui.range);
  if (ui.view === 'activities') {
    for (const key of ['search', 'domain', 'category']) {
      if (ui.detail[key]) params.set(key, ui.detail[key]);
    }
    if (ui.detail.sort !== 'recent') params.set('sort', ui.detail.sort);
    if (ui.detail.page > 1) params.set('page', String(ui.detail.page));
  }
  const query = params.toString();
  history.replaceState(null, '', `${location.pathname}${query ? `?${query}` : ''}`);
}

function switchView(view) {
  ui.view = view;
  for (const [name, refs] of Object.entries(VIEWS)) {
    els[refs.nav].setAttribute('aria-pressed', name === view ? 'true' : 'false');
    els[refs.section].hidden = name !== view;
  }
  els.rangeSelect.disabled = view === 'analysis';
  syncUrl();
}

els.navOverview.addEventListener('click', () => switchView('overview'));
els.navActivities.addEventListener('click', () => switchView('activities'));
els.navAnalysis.addEventListener('click', () => switchView('analysis'));

// ---------- 图表基础 ----------

let renderedTrend = null;

function renderDailyTrend(items, peakMs) {
  renderedTrend = { items, peakMs };
  els.dailyBars.querySelector('.daily-trend')?.remove();
  const scrollbarHeight = els.dailyBars.offsetHeight - els.dailyBars.clientHeight;
  els.dailyBars.style.setProperty('--chart-scrollbar-height', `${scrollbarHeight}px`);
  const totalWidth = Math.max(els.dailyBars.clientWidth,
    Number.parseFloat(els.dailyBars.style.getPropertyValue('--chart-content-width')) || 0);
  const gap = Number.parseFloat(getComputedStyle(els.dailyBars).columnGap) || 0;
  const columnWidth = (totalWidth - (items.length - 1) * gap) / items.length;
  const points = items.map((item, index) => ({
    x: (((index + 0.5) * columnWidth + index * gap) / totalWidth) * 100,
    y: 100 - (item.durationMs / peakMs) * 100,
  }));
  const trend = document.createElement('div');
  trend.className = 'daily-trend';
  trend.setAttribute('aria-hidden', 'true');
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.classList.add('daily-trend-line');
  svg.setAttribute('viewBox', '0 0 100 100');
  svg.setAttribute('preserveAspectRatio', 'none');
  svg.setAttribute('focusable', 'false');
  const line = document.createElementNS('http://www.w3.org/2000/svg', 'polyline');
  line.setAttribute('points', points.map((point) => `${point.x.toFixed(2)},${point.y.toFixed(2)}`).join(' '));
  line.setAttribute('fill', 'none');
  line.setAttribute('stroke', '#d97706');
  line.setAttribute('stroke-width', '2');
  line.setAttribute('stroke-linecap', 'round');
  line.setAttribute('stroke-linejoin', 'round');
  line.setAttribute('vector-effect', 'non-scaling-stroke');
  svg.appendChild(line);
  trend.appendChild(svg);
  for (const point of points) {
    const dot = document.createElement('span');
    dot.className = 'daily-point';
    dot.style.left = `${point.x}%`;
    dot.style.top = `${point.y}%`;
    trend.appendChild(dot);
  }
  els.dailyBars.appendChild(trend);
}

const TREND_TEXT = {
  day: { title: '每日分布', axis: '日期', chartLabel: '每日浏览耗时柱状图' },
  week: { title: '每周分布', axis: '周', chartLabel: '每周浏览耗时柱状图' },
  month: { title: '每月分布', axis: '月份', chartLabel: '每月浏览耗时柱状图' },
};

function weekStartMs(dateStr) {
  const d = new Date(dateStartMs(dateStr));
  d.setDate(d.getDate() - ((d.getDay() + 6) % 7)); // 以本地周一为一周起点
  return d.getTime();
}

// 逐日数据聚合成图表点：≤31 天按日，32–180 天按周，更长按月，始终保持旧到新
function aggregateTrend(dailyStats) {
  const days = Array.isArray(dailyStats) ? dailyStats : [];
  const granularity = days.length <= DAY_AGGREGATE_LIMIT ? 'day'
    : days.length <= WEEK_AGGREGATE_LIMIT_DAYS ? 'week'
      : 'month';
  const items = [];
  const groups = new Map();
  for (const day of days) {
    // 周用周一日期作分组键，月用 YYYY-MM
    const key = granularity === 'day' ? day.date
      : granularity === 'week' ? localDateStringOf(weekStartMs(day.date))
        : day.date.slice(0, 7);
    let item = groups.get(key);
    if (!item) {
      item = { key, date: key, label: '', ariaLabel: '', title: '', durationMs: 0 };
      groups.set(key, item);
      items.push(item);
    }
    item.durationMs += day.durationMs;
  }
  for (const item of items) {
    const durationText = formatDuration(item.durationMs, 'down');
    if (granularity === 'day') {
      item.label = item.key.slice(5);
      item.ariaLabel = item.key;
      item.title = `${item.key}，${durationText}`;
    } else if (granularity === 'week') {
      const start = new Date(dateStartMs(item.key));
      const end = new Date(start.getFullYear(), start.getMonth(), start.getDate() + 6);
      item.label = item.key.slice(5);
      item.ariaLabel = `${item.key} 起的一周`;
      item.title = `${item.key} ~ ${localDateStringOf(end.getTime())}，${durationText}`;
    } else {
      const [year, month] = item.key.split('-').map(Number);
      const lastDay = new Date(year, month, 0).getDate();
      item.label = `${String(year).slice(2)}-${String(month).padStart(2, '0')}`;
      item.ariaLabel = `${year}年${month}月`;
      item.title = `${item.key}-01 ~ ${item.key}-${String(lastDay).padStart(2, '0')}，${durationText}`;
    }
  }
  return { granularity, items };
}

// showPeakOnly：实际范围超过 31 天时只在非零峰值柱写数值，其余靠 title 与 aria-label 查看
function isCurrentPeriod(item, granularity) {
  const today = localDateStringOf(Date.now());
  if (granularity === 'day') return item.key === today;
  if (granularity === 'month') return item.key === today.slice(0, 7);
  return false;
}

function renderDailyChart(items, granularity, showPeakOnly) {
  const trendText = TREND_TEXT[granularity];
  els.dailyTitle.textContent = trendText.title;
  els.dailyXTitle.textContent = trendText.axis;
  els.dailyBars.setAttribute('aria-label', trendText.chartLabel);

  els.dailyBars.textContent = '';
  els.dailyBars.scrollLeft = 0;
  els.dailyYAxis.textContent = '';
  const columnWidth = 40;
  const columnGap = items.length > DAY_AGGREGATE_LIMIT ? 2 : 8;
  const contentWidth = items.length * columnWidth + Math.max(0, items.length - 1) * columnGap;
  els.dailyBars.style.gridTemplateColumns = `repeat(${items.length}, minmax(${columnWidth}px, 1fr))`;
  els.dailyBars.style.columnGap = `${columnGap}px`;
  // 标签全部显示；空间不足时让柱、折线和横轴在同一内容宽度内滚动
  els.dailyBars.style.setProperty('--chart-content-width', `${contentWidth}px`);
  const peakMinutes = Math.max(1, Math.ceil(Math.max(...items.map((item) => item.durationMs)) / 60000));
  const peakMs = peakMinutes * 60000;
  const peakValueMs = Math.max(0, ...items.map((item) => item.durationMs));
  // 峰值柱下标；并列时只标注最左侧一根，避免多个数值重新堆满图
  const peakIndex = peakValueMs > 0 ? items.findIndex((item) => item.durationMs === peakValueMs) : -1;
  for (const tick of [peakMinutes, peakMinutes / 2, 0]) {
    const label = document.createElement('span');
    label.textContent = `${Number.isInteger(tick) ? tick : tick.toFixed(1)}分`;
    els.dailyYAxis.appendChild(label);
  }
  for (const [index, item] of items.entries()) {
    const li = document.createElement('li');
    li.className = 'daily-item';
    const currentMarker = isCurrentPeriod(item, granularity) ? (granularity === 'day' ? '，今天' : '，本月') : '';
    if (currentMarker) li.classList.add('is-current');
    li.setAttribute('aria-label', `${item.ariaLabel}，${formatDuration(item.durationMs, 'down')}${currentMarker}`);
    li.title = `${item.title}${currentMarker}`;
    const value = document.createElement('span');
    value.className = 'daily-value';
    const minutes = Math.round(item.durationMs / 60000);
    const minutesText = item.durationMs > 0 && minutes < 1 ? '<1分' : `${minutes}分`;
    const showValue = showPeakOnly ? index === peakIndex : item.durationMs > 0 || items.length <= 7;
    value.textContent = showValue ? minutesText : '';
    const track = document.createElement('div');
    track.className = 'daily-track';
    const fill = document.createElement('div');
    fill.className = 'daily-column';
    fill.style.blockSize = item.durationMs <= 0 ? '0%' : `${Math.max(2, Math.round((item.durationMs / peakMs) * 100))}%`;
    track.appendChild(fill);
    const date = document.createElement('span');
    date.className = 'daily-date';
    date.textContent = item.label;
    li.append(value, track, date);
    els.dailyBars.appendChild(li);
  }
  renderDailyTrend(items, peakMs);
}

// opts.percentTotal 提供时，数值后追加占比百分比
function renderBars(container, items, labelOf, valueOf, opts = {}) {
  container.textContent = '';
  const peak = Math.max(1, ...items.map(valueOf));
  const total = opts.percentTotal || 0;
  for (const item of items) {
    const row = document.createElement('div');
    row.className = 'bar-row';
    const label = document.createElement('span');
    label.className = 'bar-label';
    label.textContent = labelOf(item);
    const track = document.createElement('div');
    track.className = 'bar-track';
    const fill = document.createElement('div');
    fill.className = 'bar-fill';
    fill.style.inlineSize = valueOf(item) <= 0 ? '0%' : `${Math.max(2, Math.round((valueOf(item) / peak) * 100))}%`;
    track.appendChild(fill);
    const value = document.createElement('span');
    value.className = 'bar-value';
    let text = formatDuration(valueOf(item), 'down');
    if (opts.percentTotal) {
      const pct = total > 0 ? (valueOf(item) / total) * 100 : 0;
      text += ` · ${Number(pct.toFixed(1))}%`;
    }
    value.textContent = text;
    row.append(label, track, value);
    container.appendChild(row);
  }
}

// ---------- 统计概览 ----------

function renderSummary(data) {
  els.statTotal.textContent = formatDuration(data.totalDurationMs, 'down');
  els.statSites.textContent = String(data.domainStats.length);
  els.statActiveDays.textContent = String(data.dailyStats.filter((d) => d.durationMs > 0).length);

  const merged = new Array(24).fill(0);
  for (const day of data.hourly) {
    for (let h = 0; h < 24; h++) merged[h] += day.slots[h];
  }
  const peakMs = Math.max(0, ...merged);
  const peakHour = peakMs > 0 ? merged.indexOf(peakMs) : -1;
  if (peakHour < 0 || peakMs <= 0) {
    els.statPeakHour.textContent = '数据不足';
  } else {
    const p = (n) => String(n).padStart(2, '0');
    const endHour = (peakHour + 1) % 24;
    els.statPeakHour.textContent = `${p(peakHour)}:00–${p(endHour)}:00`;
  }
}

function renderHourly(data) {
  els.hourlyChart.textContent = '';
  els.hourlyX.textContent = '';
  const available = Boolean(data.hourlyAvailable);
  els.hourlyEmpty.hidden = available;
  els.hourlyChart.hidden = !available;
  els.hourlyX.hidden = !available;
  if (!available) {
    els.hourlyMeta.textContent = '';
    return;
  }
  const merged = new Array(24).fill(0);
  for (const day of data.hourly) {
    for (let h = 0; h < 24; h++) merged[h] += day.slots[h];
  }
  const peak = Math.max(1, ...merged);
  let peakHour = 0;
  for (let h = 1; h < 24; h++) if (merged[h] > merged[peakHour]) peakHour = h;
  const p = (n) => String(n).padStart(2, '0');
  els.hourlyMeta.textContent = `覆盖 ${data.hourlyCoveredDays} 天，峰值约 ${p(peakHour)}:00（${formatDuration(merged[peakHour], 'down')}）`;
  for (let h = 0; h < 24; h++) {
    const col = document.createElement('div');
    col.className = 'hourly-col';
    const fill = document.createElement('div');
    fill.className = 'hourly-fill';
    fill.style.blockSize = merged[h] <= 0 ? '0%' : `${Math.max(2, Math.round((merged[h] / peak) * 100))}%`;
    col.appendChild(fill);
    els.hourlyChart.appendChild(col);
  }
  for (let h = 0; h < 24; h++) {
    const label = document.createElement('span');
    label.textContent = h % 3 === 0 ? String(h) : '';
    els.hourlyX.appendChild(label);
  }
}

function domainColor(domain) {
  let h = 0;
  for (let i = 0; i < domain.length; i++) h = (h * 31 + domain.charCodeAt(i)) >>> 0;
  return TIMELINE_PALETTE[h % TIMELINE_PALETTE.length];
}

function renderTimeline(data) {
  els.timelineChart.textContent = '';
  els.timelineLegend.textContent = '';
  const cutoff = dateStartMs(localDateStringOf(Date.now() - 2 * DAY_MS));
  const segments = (data.recentSegments || []).filter((s) => s.endTs >= cutoff);
  const hasData = segments.length > 0;
  els.timelineEmpty.hidden = hasData;
  els.timelineChart.hidden = !hasData;
  els.timelineLegend.hidden = !hasData;
  if (!hasData) return;

  const byDomain = new Map();
  for (const s of segments) {
    byDomain.set(s.domain, (byDomain.get(s.domain) || 0) + s.durationMs);
  }
  const topDomains = [...byDomain.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5);
  for (const [domain, ms] of topDomains) {
    const item = document.createElement('span');
    item.className = 'legend-item';
    const chip = document.createElement('span');
    chip.className = 'legend-chip';
    chip.style.background = domainColor(domain);
    const text = document.createElement('span');
    text.textContent = `${domain} · ${formatDuration(ms, 'down')}`;
    item.append(chip, text);
    els.timelineLegend.appendChild(item);
  }

  const byDate = new Map();
  for (const s of segments) {
    const date = localDateStringOf(s.endTs);
    if (!byDate.has(date)) byDate.set(date, []);
    byDate.get(date).push(s);
  }
  const todayStr = localDateStringOf(Date.now());
  const dates = [];
  for (let i = 2; i >= 0; i--) dates.push(localDateStringOf(Date.now() - i * DAY_MS));
  const dayName = (date) => {
    if (date === todayStr) return '今天';
    if (date === localDateStringOf(Date.now() - DAY_MS)) return '昨天';
    return formatDay(date);
  };
  for (const date of dates) {
    const daySegments = (byDate.get(date) || []).slice().sort((a, b) => a.startTs - b.startTs);
    const row = document.createElement('div');
    row.className = 'timeline-day';
    const label = document.createElement('span');
    label.className = 'timeline-label';
    label.textContent = dayName(date);
    const track = document.createElement('div');
    track.className = 'timeline-track';
    const dayStart = dateStartMs(date);
    for (const s of daySegments) {
      const startPct = Math.min(99, Math.max(0, ((s.startTs - dayStart) / DAY_MS) * 100));
      const widthPct = Math.min(100 - startPct, Math.max(0.5, (s.durationMs / DAY_MS) * 100));
      const seg = document.createElement('div');
      seg.className = 'timeline-seg';
      seg.style.background = domainColor(s.domain);
      seg.style.insetInlineStart = `${startPct}%`;
      seg.style.inlineSize = `${widthPct}%`;
      seg.setAttribute('aria-label', `${s.domain}，${formatTime(s.startTs)}–${formatTime(s.endTs)}，实际时长 ${formatDuration(s.durationMs, 'down')}`);
      track.appendChild(seg);
    }
    row.append(label, track);
    els.timelineChart.appendChild(row);
  }
}

// 概览数据不再携带 activities，空态只看总耗时
function isDashboardEmpty(data) {
  return data.totalDurationMs <= 0;
}

// 记录起点晚于范围首日时说明更早的数据未保存，避免把缺数据当成没使用
function renderRangeNote(data) {
  const dataStartDate = data.dataStartDate || '';
  const startDate = data.startDate || '';
  const needsNote = Boolean(dataStartDate)
    && (data.range === 'all' || (data.rangeDays > DAY_AGGREGATE_LIMIT && dataStartDate > startDate));
  if (isDashboardEmpty(data) || !needsNote) {
    els.rangeNote.textContent = '';
    els.rangeNote.hidden = true;
    return;
  }
  els.rangeNote.textContent = `现有记录从 ${dataStartDate} 开始；此前未保存的数据无法恢复。`;
  els.rangeNote.hidden = false;
}

function renderOverview(data) {
  const isEmpty = isDashboardEmpty(data);
  // 标题跟随本范围是否有 LLM 分类命中，空态也要复位，避免残留上一次的范围标题
  els.categoryTitle.textContent = Number(data.llmCategoryCount) > 0
    ? '分类分布（LLM + 本地规则）'
    : '分类分布（本地）';
  els.emptyEl.hidden = !isEmpty;
  els.summaryBand.hidden = isEmpty;
  els.dataGrid.hidden = isEmpty;
  for (const note of els.truncateNotes) {
    note.hidden = !data.activityTruncated;
  }
  if (isEmpty) {
    renderHourly(data);
    renderTimeline(data);
    return;
  }

  renderSummary(data);
  renderBars(els.categoryBars, data.categoryStats.filter((c) => c.durationMs > 0),
    (c) => c.category, (c) => c.durationMs, { percentTotal: data.totalDurationMs });

  const MAX_DOMAINS = 10;
  const shown = data.domainStats.slice(0, MAX_DOMAINS);
  renderBars(els.domainBars, shown, (d) => d.domain, (d) => d.durationMs, { percentTotal: data.totalDurationMs });
  if (data.domainStats.length > MAX_DOMAINS) {
    els.domainCount.hidden = false;
    els.domainCount.textContent = `共 ${data.domainStats.length} 个网站，仅显示耗时前 ${MAX_DOMAINS} 个`;
  } else {
    els.domainCount.hidden = true;
    els.domainCount.textContent = '';
  }

  const trend = aggregateTrend(data.dailyStats);
  // 数值文本是否稀疏跟随实际范围天数，而不是聚合后的柱子数量
  renderDailyChart(trend.items, trend.granularity, data.rangeDays > DAY_AGGREGATE_LIMIT);
  renderHourly(data);
  renderTimeline(data);
}

// ---------- 活动明细 ----------

function fillDetailOptions(data) {
  const domainValue = ui.detail.domain;
  const categoryValue = ui.detail.category;
  els.detailDomain.textContent = '';
  const allDomains = document.createElement('option');
  allDomains.value = '';
  allDomains.textContent = '全部网站';
  els.detailDomain.appendChild(allDomains);
  for (const d of data.domainStats) {
    const option = document.createElement('option');
    option.value = d.domain;
    option.textContent = d.domain;
    els.detailDomain.appendChild(option);
  }
  els.detailDomain.value = [...els.detailDomain.options].some((o) => o.value === domainValue) ? domainValue : '';
  ui.detail.domain = els.detailDomain.value;

  els.detailCategory.textContent = '';
  const allCategories = document.createElement('option');
  allCategories.value = '';
  allCategories.textContent = '全部分类';
  els.detailCategory.appendChild(allCategories);
  for (const c of data.categories) {
    const option = document.createElement('option');
    option.value = c;
    option.textContent = c;
    els.detailCategory.appendChild(option);
  }
  els.detailCategory.value = [...els.detailCategory.options].some((o) => o.value === categoryValue) ? categoryValue : '';
  ui.detail.category = els.detailCategory.value;
}

const ACTIVITY_COLORS = ['#4f46e5', '#0e7490', '#b45309', '#047857', '#be185d', '#6d28d9', '#1d4ed8', '#a16207', '#0f766e', '#7c2d12'];

function activityColor(category) {
  const index = Math.max(0, ['学习', '工作', '开发', '社交', '资讯', '搜索', '购物', '娱乐', '工具', '其他'].indexOf(category));
  return ACTIVITY_COLORS[index % ACTIVITY_COLORS.length];
}

function renderActivityOverview(data) {
  els.activityTotal.textContent = formatDuration(data.totalDurationMs, 'down');
  const topSite = data.domainStats[0];
  els.activitySummary.textContent = topSite
    ? `${data.domainStats.length} 个网站 · ${topSite.domain} 最常用`
    : '这个时间段还没有活动记录';

  els.activityTrend.textContent = '';
  const days = data.dailyStats.slice(-7);
  const peak = Math.max(1, ...days.map((day) => day.durationMs));
  for (const day of days) {
    const bar = document.createElement('span');
    bar.className = 'activity-trend-bar';
    bar.style.setProperty('--bar-height', `${Math.max(4, Math.round(day.durationMs / peak * 100))}%`);
    bar.title = `${day.date}，${formatDuration(day.durationMs, 'down')}`;
    els.activityTrend.appendChild(bar);
  }

  els.activityCategories.textContent = '';
  for (const category of data.categoryStats.filter((item) => item.durationMs > 0)) {
    const percent = data.totalDurationMs > 0 ? Math.round(category.durationMs / data.totalDurationMs * 100) : 0;
    const item = document.createElement('span');
    item.className = 'activity-category';
    item.style.setProperty('--activity-color', activityColor(category.category));
    item.style.flexGrow = String(Math.max(percent, 8));
    item.textContent = `${category.category} ${percent}%`;
    els.activityCategories.appendChild(item);
  }
}

function renderActivityCards(activities) {
  els.activityDays.textContent = '';
  const byDate = new Map();
  for (const activity of activities) {
    const date = localDateStringOf(activity.lastTs);
    if (!byDate.has(date)) byDate.set(date, []);
    byDate.get(date).push(activity);
  }
  const today = localDateStringOf(Date.now());
  const maxDuration = Math.max(1, ...activities.map((activity) => activity.durationMs));

  for (const [date, items] of [...byDate.entries()].sort((a, b) => b[0].localeCompare(a[0]))) {
    const day = document.createElement('section');
    day.className = 'activity-day';
    day.setAttribute('aria-label', `${date} 的活动`);
    const head = document.createElement('header');
    head.className = 'activity-day-head';
    const name = document.createElement('strong');
    name.textContent = date === today ? '今天' : formatDay(date);
    const count = document.createElement('span');
    count.textContent = `${items.length} 条活动`;
    head.append(name, count);

    const list = document.createElement('div');
    list.className = 'activity-day-list';
    for (const activity of items) {
      const color = activityColor(activity.category);
      const card = document.createElement('article');
      card.className = 'activity-card';
      card.style.setProperty('--activity-color', color);

      const avatar = document.createElement('span');
      avatar.className = 'activity-avatar';
      avatar.textContent = activity.domain.slice(0, 1).toUpperCase();
      avatar.setAttribute('aria-hidden', 'true');

      const copy = document.createElement('div');
      copy.className = 'activity-card-copy';
      const title = document.createElement('h3');
      title.textContent = activity.title;
      const site = document.createElement('p');
      site.textContent = `${activity.domain} · ${formatTime(activity.lastTs)}`;
      copy.append(title, site);

      const meta = document.createElement('div');
      meta.className = 'activity-card-meta';
      const category = document.createElement('span');
      category.className = 'activity-card-category';
      category.textContent = activity.category;
      const duration = document.createElement('strong');
      duration.textContent = formatDuration(activity.durationMs, 'down');
      meta.append(category, duration);

      const track = document.createElement('div');
      track.className = 'activity-duration-track';
      track.setAttribute('aria-hidden', 'true');
      const fill = document.createElement('i');
      fill.style.inlineSize = `${Math.max(4, Math.round(activity.durationMs / maxDuration * 100))}%`;
      track.appendChild(fill);
      card.append(avatar, copy, meta, track);
      list.appendChild(card);
    }
    day.append(head, list);
    els.activityDays.appendChild(day);
  }
}

function renderDetailRows(activities) {
  els.detailTbody.textContent = '';
  for (const a of activities) {
    const tr = document.createElement('tr');

    const time = document.createElement('td');
    time.dataset.label = '最近时间';
    time.textContent = formatDateTime(a.lastTs);

    const domain = document.createElement('td');
    domain.dataset.label = '网站';
    domain.className = 'cell-domain';
    domain.textContent = a.domain;

    const title = document.createElement('td');
    title.dataset.label = '页面标题';
    title.className = 'cell-title';
    title.textContent = a.title;

    const category = document.createElement('td');
    category.dataset.label = '分类';
    category.textContent = a.category;

    const duration = document.createElement('td');
    duration.dataset.label = '耗时';
    duration.className = 'num';
    duration.textContent = formatDuration(a.durationMs, 'down');

    tr.append(time, domain, title, category, duration);
    els.detailTbody.appendChild(tr);
  }
}

// 明细由后台按范围+筛选分页，这里只渲染后台返回的当前页
function renderDetailPage(data) {
  ui.detail.page = data.page; // 后台可能已夹取页码，前端跟随
  syncUrl();
  renderActivityCards(data.activities);
  renderDetailRows(data.activities);
  els.detailCount.textContent = data.total > 0 ? `共 ${data.total} 条` : '';
  els.detailEmpty.hidden = data.total > 0;
  els.pageInfo.textContent = data.total > 0 ? `第 ${data.page} / ${data.pages} 页` : '';
  els.prevPage.disabled = data.page <= 1;
  els.nextPage.disabled = data.page >= data.pages;
}

async function loadActivities() {
  const mySeq = ++ui.detailSeq;
  // 请求期间先清空，避免显示上一个范围或筛选的旧行
  els.detailTbody.textContent = '';
  els.activityDays.textContent = '';
  els.detailCount.textContent = '正在读取记录…';
  els.detailEmpty.hidden = true;
  els.pageInfo.textContent = '';
  els.prevPage.disabled = true;
  els.nextPage.disabled = true;
  let res;
  try {
    res = await chrome.runtime.sendMessage({
      type: 'getActivityPage',
      range: currentRange(),
      search: ui.detail.search,
      domain: ui.detail.domain,
      category: ui.detail.category,
      sort: ui.detail.sort,
      page: ui.detail.page,
    });
  } catch (err) {
    if (mySeq !== ui.detailSeq) return;
    els.detailCount.textContent = '';
    setStatus(`读取明细失败：${err && err.message ? err.message : err}`, true);
    return;
  }
  if (mySeq !== ui.detailSeq) return; // 已有更新的明细请求，丢弃旧响应
  if (!res || !res.ok) {
    els.detailCount.textContent = '';
    setStatus(`读取明细失败：${res ? res.error : '未知错误'}`, true);
    return;
  }
  if (els.statusEl.textContent.startsWith('读取明细失败')) setStatus('', false);
  renderDetailPage(res.data);
}

function renderAll(data) {
  renderOverview(data);
  renderRangeNote(data);
  fillDetailOptions(data);
  renderActivityOverview(data);
}

// select 只提供这 8 个值，异常值回落到默认范围
function currentRange() {
  return RANGES.includes(els.rangeSelect.value) ? els.rangeSelect.value : DEFAULT_RANGE;
}

async function loadDashboard(resetPage = true) {
  const mySeq = ++ui.seq;
  ui.detailSeq += 1; // 范围变化后，旧范围的明细请求作废
  els.loadingEl.hidden = false;
  let res;
  try {
    res = await chrome.runtime.sendMessage({
      type: 'getDashboardData',
      range: currentRange(),
      includeActivities: false,
    });
  } catch (err) {
    if (mySeq !== ui.seq) return;
    els.loadingEl.hidden = true;
    setStatus(`读取统计失败：${err && err.message ? err.message : err}`, true);
    return;
  }
  if (mySeq !== ui.seq) return; // 已有更新的请求，丢弃旧响应
  els.loadingEl.hidden = true;
  if (!res || !res.ok) {
    setStatus(`读取统计失败：${res ? res.error : '未知错误'}`, true);
    return;
  }
  if (resetPage) ui.detail.page = 1;
  renderAll(res.data);
  await loadActivities();
}

els.rangeSelect.addEventListener('change', () => {
  ui.range = currentRange();
  syncUrl();
  if (ui.view !== 'analysis') loadDashboard();
});

els.detailSearch.addEventListener('input', () => {
  ui.detail.search = els.detailSearch.value;
  ui.detail.page = 1;
  syncUrl();
  loadActivities();
});
els.detailDomain.addEventListener('change', () => {
  ui.detail.domain = els.detailDomain.value;
  ui.detail.page = 1;
  syncUrl();
  loadActivities();
});
els.detailCategory.addEventListener('change', () => {
  ui.detail.category = els.detailCategory.value;
  ui.detail.page = 1;
  syncUrl();
  loadActivities();
});
els.detailSort.addEventListener('change', () => {
  ui.detail.sort = els.detailSort.value;
  ui.detail.page = 1;
  syncUrl();
  loadActivities();
});
els.prevPage.addEventListener('click', () => {
  if (ui.detail.page <= 1) return;
  ui.detail.page -= 1;
  syncUrl();
  loadActivities();
});
els.nextPage.addEventListener('click', () => {
  ui.detail.page += 1;
  syncUrl();
  loadActivities();
});

// ---------- 偏好分析 ----------

function renderAiOrbit(analysis) {
  els.aiOrbitNodes.textContent = '';
  const stats = Array.isArray(analysis && analysis.categoryStats) ? analysis.categoryStats : [];
  const total = stats.reduce((sum, item) => sum + item.durationMs, 0);
  for (const [index, item] of stats.slice(0, 5).entries()) {
    const percent = total > 0 ? Math.round(item.durationMs / total * 100) : 0;
    const node = document.createElement('span');
    node.className = `ai-orbit-node node-${index}`;
    node.style.setProperty('--node-color', activityColor(item.category));
    node.textContent = `${item.category} ${percent}%`;
    els.aiOrbitNodes.appendChild(node);
  }
}

function renderAnalysisEmpty() {
  els.analysisResult.textContent = '';
  els.aiOrbitNodes.textContent = '';
  els.aiEvidenceContent.textContent = '';
  const p = document.createElement('p');
  p.className = 'analysis-empty';
  p.textContent = '还没有分析结果。配置服务后点击「开始分析」生成。';
  els.analysisResult.appendChild(p);
}

function renderAnalysis(analysis) {
  els.analysisResult.textContent = '';
  if (!analysis) {
    renderAnalysisEmpty();
    return;
  }

  const meta = document.createElement('p');
  meta.className = 'analysis-meta';
  meta.textContent = `模型 ${analysis.modelName} · ${formatDateTime(analysis.createdAt)} · 近 ${analysis.rangeDays} 天`;

  const summary = document.createElement('p');
  summary.className = 'analysis-summary';
  summary.textContent = analysis.summary;

  els.analysisResult.append(meta, summary);

  if (Array.isArray(analysis.insights) && analysis.insights.length > 0) {
    const list = document.createElement('ol');
    list.className = 'insight-list';
    for (const insight of analysis.insights) {
      const li = document.createElement('li');
      const title = document.createElement('strong');
      title.textContent = insight.title;
      li.appendChild(title);
      if (insight.detail) {
        const detail = document.createElement('p');
        detail.textContent = insight.detail;
        li.appendChild(detail);
      }
      if (insight.suggestion) {
        const suggestion = document.createElement('p');
        suggestion.className = 'suggestion';
        suggestion.textContent = `建议：${insight.suggestion}`;
        li.appendChild(suggestion);
      }
      list.appendChild(li);
    }
    els.analysisResult.appendChild(list);
  }

  const note = document.createElement('p');
  note.className = 'analysis-note';
  note.textContent = '以下分类为 LLM 推断，可能误判；时长按本地记录重新计算。';
  els.analysisResult.appendChild(note);

  renderAiOrbit(analysis);
  els.aiEvidenceContent.textContent = '';

  if (Array.isArray(analysis.classifiedActivities) && analysis.classifiedActivities.length > 0) {
    const list = document.createElement('ul');
    list.className = 'classified-list';
    for (const a of analysis.classifiedActivities) {
      const li = document.createElement('li');
      const title = document.createElement('p');
      title.className = 'classified-title';
      title.textContent = a.title;
      const metaLine = document.createElement('p');
      metaLine.className = 'classified-meta';
      metaLine.textContent = `${a.domain} · ${a.category} · ${formatDuration(a.durationMs, 'down')}`;
      li.append(title, metaLine);
      list.appendChild(li);
    }
    els.aiEvidenceContent.appendChild(list);
  }
}

async function loadLatestAnalysis() {
  try {
    const res = await chrome.runtime.sendMessage({ type: 'getLatestAnalysis' });
    renderAnalysis(res && res.ok ? res.analysis : null);
  } catch (err) {
    renderAnalysis(null);
  }
}

els.analyzeBtn.addEventListener('click', async () => {
  if (els.analyzeBtn.disabled) return;
  els.analyzeBtn.disabled = true;
  els.analyzeBtn.textContent = '分析中…';
  els.viewAnalysis.classList.add('is-analyzing');
  try {
    const res = await chrome.runtime.sendMessage({ type: 'analyzeBrowsing' });
    if (!res || !res.ok) {
      setStatus(`分析失败：${res ? res.error : '未知错误'}`, true);
    } else {
      setStatus('分析完成。', false);
      renderAnalysis(res.analysis);
      // 分类覆盖已落库，立即刷新概览与明细；不切换当前视图
      await loadDashboard();
    }
  } catch (err) {
    setStatus(`分析失败：${err && err.message ? err.message : err}`, true);
  } finally {
    els.analyzeBtn.disabled = false;
    els.analyzeBtn.textContent = '开始分析';
    els.viewAnalysis.classList.remove('is-analyzing');
  }
});

// ---------- 清除历史 ----------

els.clearBtn.addEventListener('click', () => {
  els.confirmDialog.showModal();
});

els.confirmDialog.addEventListener('close', async () => {
  if (els.confirmDialog.returnValue !== 'confirm') return;
  els.clearBtn.disabled = true;
  try {
    const res = await chrome.runtime.sendMessage({ type: 'clearAnalytics' });
    if (!res || !res.ok) {
      setStatus(`清除失败：${res ? res.error : '未知错误'}`, true);
      return;
    }
    renderAnalysis(null);
    await loadDashboard();
    setStatus('已清除浏览历史，规则与模型设置已保留。', false);
  } catch (err) {
    setStatus(`清除失败：${err && err.message ? err.message : err}`, true);
  } finally {
    els.clearBtn.disabled = false;
  }
});

// ---------- LLM 设置 ----------

function applyLlmConfig(config) {
  els.baseUrlInput.value = config.baseUrl || '';
  els.modelNameInput.value = config.modelName || '';
  els.apiKeyInput.value = '';
  els.apiKeyInput.placeholder = config.hasApiKey ? '已保存，留空则保持不变' : 'sk-...';
  els.clearKeyBtn.disabled = !config.hasApiKey;
}

els.toggleKeyBtn.addEventListener('click', () => {
  const show = els.apiKeyInput.type === 'password';
  els.apiKeyInput.type = show ? 'text' : 'password';
  els.toggleKeyBtn.textContent = show ? '隐藏' : '显示';
  els.toggleKeyBtn.setAttribute('aria-pressed', String(show));
  const label = show ? '隐藏密钥' : '显示密钥';
  els.toggleKeyBtn.setAttribute('aria-label', label);
  els.toggleKeyBtn.title = label;
});

async function loadLlmConfig() {
  try {
    const res = await chrome.runtime.sendMessage({ type: 'getLlmConfig' });
    if (res && res.ok) applyLlmConfig(res.config);
  } catch (err) {
    setStatus(`读取模型设置失败：${err && err.message ? err.message : err}`, true);
  }
}

els.llmForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  if (!els.llmForm.checkValidity()) {
    els.llmForm.reportValidity();
    return;
  }
  els.saveBtn.disabled = true;
  els.saveBtn.textContent = '保存中…';
  try {
    const res = await chrome.runtime.sendMessage({
      type: 'saveLlmConfig',
      baseUrl: els.baseUrlInput.value,
      modelName: els.modelNameInput.value,
      apiKey: els.apiKeyInput.value,
    });
    if (!res || !res.ok) {
      setStatus(`保存失败：${res ? res.error : '未知错误'}`, true);
      return;
    }
    setStatus('设置已保存。', false);
    els.apiKeyInput.value = '';
    applyLlmConfig(res.config);
  } catch (err) {
    setStatus(`保存失败：${err && err.message ? err.message : err}`, true);
  } finally {
    els.saveBtn.disabled = false;
    els.saveBtn.textContent = '保存设置';
  }
});

els.testBtn.addEventListener('click', async () => {
  els.testBtn.disabled = true;
  els.testBtn.textContent = '测试中…';
  try {
    const res = await chrome.runtime.sendMessage({ type: 'testLlmConnection' });
    if (!res || !res.ok) {
      setStatus(`连接失败：${res ? res.error : '未知错误'}`, true);
    } else {
      setStatus(res.message || '连接成功。', false);
    }
  } catch (err) {
    setStatus(`连接失败：${err && err.message ? err.message : err}`, true);
  } finally {
    els.testBtn.disabled = false;
    els.testBtn.textContent = '测试连接';
  }
});

els.clearKeyBtn.addEventListener('click', async () => {
  els.clearKeyBtn.disabled = true;
  try {
    const res = await chrome.runtime.sendMessage({ type: 'clearLlmApiKey' });
    if (!res || !res.ok) {
      setStatus(`清除密钥失败：${res ? res.error : '未知错误'}`, true);
      return;
    }
    setStatus('已清除 API Key。', false);
    applyLlmConfig(res.config);
  } catch (err) {
    setStatus(`清除密钥失败：${err && err.message ? err.message : err}`, true);
  } finally {
    els.clearKeyBtn.disabled = !els.apiKeyInput.placeholder.includes('已保存');
  }
});

// 宽度变化时重算折点，避免与柱中心错位
const trendObserver = new ResizeObserver(() => {
  if (renderedTrend) renderDailyTrend(renderedTrend.items, renderedTrend.peakMs);
});
trendObserver.observe(els.dailyBars);

els.rangeSelect.value = ui.range;
els.detailSearch.value = ui.detail.search;
els.detailSort.value = ui.detail.sort;
switchView(ui.view);
loadDashboard(false);
loadLlmConfig();
loadLatestAnalysis();
