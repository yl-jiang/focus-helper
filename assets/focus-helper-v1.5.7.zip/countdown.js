'use strict';

// 专注助手：受限网站右上角倒计时浮层（content script，仅顶层 http/https 页面）。
// 只读取 location.href，不读取页面正文；样式经 Shadow DOM + adoptedStyleSheets 与页面隔离。
// 计时本体在后台 tick，本脚本只做展示：每 30 秒同步，计时中按收到的 remainingMs 本地每秒递减。

(() => {
  const HOST_ID = 'focus-helper-countdown';
  const SYNC_INTERVAL_MS = 30000;
  const COUNTDOWN_INTERVAL_MS = 1000;

  // 防重复注入双保险（all_frames:false 下 content script 只注入顶层一次）
  if (window !== window.top) return;
  if (document.getElementById(HOST_ID)) return;
  if (!/^https?:$/.test(location.protocol)) return;

  let seq = 0;            // 同步序号：并发响应乱序时只认最新一次
  let current = null;     // { rule: {domain,remainingMs,expired}|null, isCounting }
  let receivedAt = 0;     // 最近一次同步接收时间戳，本地递减基准
  let mounted = false;
  let lastShownTime = '';
  let lastShownStatus = '';

  const host = document.createElement('div');
  host.id = HOST_ID;
  // 关键定位写内联样式，避免被页面 CSS 覆盖；窄屏靠 max-width 不溢出
  host.style.cssText = 'position:fixed;top:12px;right:12px;z-index:2147483647;pointer-events:auto;display:none;';

  const shadow = host.attachShadow({ mode: 'closed' });
  const sheet = new CSSStyleSheet();
  sheet.replaceSync(`
    .card {
      box-sizing: border-box;
      display: grid;
      gap: 3px;
      max-width: min(220px, calc(100vw - 24px));
      padding: 10px 14px;
      font: 12px/1.5 -apple-system, "PingFang SC", "Microsoft YaHei", system-ui, sans-serif;
      color: #31302e;
      background: #ffffff;
      border: 1px solid rgb(49 48 46 / 14%);
      border-radius: 10px;
      box-shadow: 0 4px 14px rgb(49 48 46 / 0.10);
      cursor: grab;
      -webkit-user-select: none;
      user-select: none;
    }
    .card.dragging { cursor: grabbing; box-shadow: 0 6px 18px rgb(49 48 46 / 0.16); }
    .cd-head { display: flex; align-items: center; gap: 8px; }
    .cd-label { font-size: 11px; color: #615d59; }
    .cd-time { font-size: 21px; font-weight: 600; line-height: 1.25; font-variant-numeric: tabular-nums; }
    .cd-status { font-size: 11px; color: #4f46e5; }
    .cd-status.paused { color: #615d59; }
    .cd-status.expired { color: #b42318; }
  `);
  shadow.adoptedStyleSheets = [sheet];

  const card = document.createElement('div');
  card.className = 'card';
  card.title = '按住鼠标左键拖动位置';
  // role=timer 默认 aria-live=off，不会逐秒打扰屏幕阅读器
  card.setAttribute('role', 'timer');
  const head = document.createElement('div');
  head.className = 'cd-head';
  const label = document.createElement('span');
  label.className = 'cd-label';
  label.textContent = '今日剩余';
  head.append(label);
  const timeEl = document.createElement('span');
  timeEl.className = 'cd-time';
  const statusEl = document.createElement('span');
  statusEl.className = 'cd-status';
  card.append(head, timeEl, statusEl);
  shadow.append(card);

  let drag = null;

  function moveTo(left, top) {
    const { width, height } = host.getBoundingClientRect();
    const maxLeft = Math.max(0, window.innerWidth - width);
    const maxTop = Math.max(0, window.innerHeight - height);
    host.style.right = 'auto';
    host.style.bottom = 'auto';
    host.style.left = `${Math.max(0, Math.min(left, maxLeft))}px`;
    host.style.top = `${Math.max(0, Math.min(top, maxTop))}px`;
  }

  function startDrag(event) {
    if (event.button !== 0 || event.pointerType !== 'mouse') return;
    event.preventDefault();
    const rect = host.getBoundingClientRect();
    drag = { pointerId: event.pointerId, offsetX: event.clientX - rect.left, offsetY: event.clientY - rect.top };
    card.setPointerCapture(event.pointerId);
    card.classList.add('dragging');
  }

  function moveDrag(event) {
    if (!drag || event.pointerId !== drag.pointerId) return;
    event.preventDefault();
    moveTo(event.clientX - drag.offsetX, event.clientY - drag.offsetY);
  }

  function stopDrag() {
    if (!drag) return;
    if (card.hasPointerCapture(drag.pointerId)) card.releasePointerCapture(drag.pointerId);
    drag = null;
    card.classList.remove('dragging');
  }

  card.addEventListener('pointerdown', startDrag);
  card.addEventListener('pointermove', moveDrag);
  card.addEventListener('pointerup', stopDrag);
  card.addEventListener('pointercancel', stopDrag);
  card.addEventListener('lostpointercapture', stopDrag);
  window.addEventListener('resize', () => {
    if (!host.style.left) return;
    const rect = host.getBoundingClientRect();
    moveTo(rect.left, rect.top);
  });

  function mount() {
    if (!mounted) {
      document.documentElement.appendChild(host);
      mounted = true;
    }
  }

  function hide() {
    host.style.display = 'none';
    lastShownTime = '';
    lastShownStatus = '';
  }

  // 小时以上 h:mm:ss，否则 mm:ss
  function formatRemaining(ms) {
    const total = Math.max(0, Math.floor(ms / 1000));
    const h = Math.floor(total / 3600);
    const m = Math.floor((total % 3600) / 60);
    const s = total % 60;
    const p = (n) => String(n).padStart(2, '0');
    return h > 0 ? `${h}:${p(m)}:${p(s)}` : `${p(m)}:${p(s)}`;
  }

  function isLive() {
    return Boolean(current && current.isCounting && !document.hidden && document.hasFocus());
  }

  function render() {
    if (!current || !current.rule) {
      hide();
      return;
    }
    const rule = current.rule;
    mount();
    host.style.display = 'block';
    const remaining = rule.expired ? 0 : (isLive() ? Math.max(0, rule.remainingMs - (Date.now() - receivedAt)) : rule.remainingMs);
    const timeText = formatRemaining(remaining);
    if (timeText !== lastShownTime) {
      timeEl.textContent = timeText;
      lastShownTime = timeText;
    }
    let statusText = '已暂停';
    let statusClass = 'cd-status paused';
    if (rule.expired || remaining <= 0) {
      statusText = '已用完';
      statusClass = 'cd-status expired';
    } else if (isLive()) {
      statusText = '计时中';
      statusClass = 'cd-status';
    }
    if (statusText !== lastShownStatus) {
      statusEl.textContent = statusText;
      statusEl.className = statusClass;
      lastShownStatus = statusText;
    }
  }

  async function sync() {
    const mySeq = ++seq;
    let res;
    try {
      res = await chrome.runtime.sendMessage({ type: 'getPageStatus', url: location.href });
    } catch (err) {
      // 扩展被重载或后台不可达：隐藏，避免旧倒计时误导
      current = null;
      render();
      return;
    }
    if (mySeq !== seq) return; // 已有更新的同步，丢弃乱序响应
    if (!res || !res.ok) {
      current = null;
      render();
      return;
    }
    current = { rule: res.rule, isCounting: Boolean(res.isCounting) };
    receivedAt = Date.now();
    if (res.rule) {
      card.setAttribute('aria-label', `专注助手：${res.rule.domain} 今日剩余，${res.rule.expired ? '已用完' : (res.isCounting ? '计时中' : '已暂停')}`);
    }
    render();
  }

  // 初始同步 + 30 秒周期同步（同步时读取 location.href，支持 SPA 换站）
  sync();
  setInterval(sync, SYNC_INTERVAL_MS);
  // 每秒重绘：仅计时中且页面前台聚焦时本地递减，其余状态显示同步值
  setInterval(render, COUNTDOWN_INTERVAL_MS);

  document.addEventListener('visibilitychange', () => {
    if (document.hidden) render();
    else sync();
  });
  window.addEventListener('focus', sync);
  window.addEventListener('blur', () => {
    render();
    sync();
  });
})();
