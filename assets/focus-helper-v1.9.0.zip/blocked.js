'use strict';

await FocusI18n.init();
FocusI18n.apply();

const params = new URLSearchParams(location.search);
const site = params.get('site');
const siteLine = document.getElementById('site-line');
if (site) {
  siteLine.textContent = FocusI18n.t('blockedSite', site);
  siteLine.hidden = false;
}

document.getElementById('close-tab').addEventListener('click', async () => {
  const status = document.getElementById('status');
  try {
    const tab = await chrome.tabs.getCurrent();
    if (tab && tab.id !== undefined) {
      await chrome.tabs.remove(tab.id);
      return;
    }
    window.close();
  } catch (err) {
    status.textContent = FocusI18n.t('closeTabFailed');
  }
});
