'use strict';

const FocusI18n = (() => {
  const STORAGE_KEY = 'languagePreference';
  const PREFERENCES = ['browser', 'zh_CN', 'en'];
  let preference = 'browser';
  let messages = null;

  function normalize(value) {
    return PREFERENCES.includes(value) ? value : 'browser';
  }

  // 手动模式没有 chrome.i18n，按 messages.json 的 $1…$n 规则自行替换；
  // 用函数型 replacer，避免替换值中的 $& 等被当成替换模式。
  function substitute(template, substitutions) {
    const values = Array.isArray(substitutions) ? substitutions : substitutions == null ? [] : [substitutions];
    return template.replace(/\$(\d+)/g, (match, index) => {
      const value = values[Number(index) - 1];
      return value === undefined ? match : String(value);
    });
  }

  function manualMessage(key, substitutions) {
    const entry = messages && messages[key];
    return entry && typeof entry.message === 'string' ? substitute(entry.message, substitutions) : '';
  }

  const t = (key, substitutions) => (messages ? manualMessage(key, substitutions) : chrome.i18n.getMessage(key, substitutions));

  // 以实际生效的消息来源为准，保证 lang 与显示文案一致
  const locale = () => (messages ? preference.replace('_', '-') : chrome.i18n.getUILanguage());
  const isChinese = () => locale().toLowerCase().startsWith('zh');

  async function loadMessages(name) {
    try {
      const response = await fetch(chrome.runtime.getURL(`_locales/${name}/messages.json`));
      if (!response.ok) {
        console.warn('[i18n] failed to load', name);
        return null;
      }
      return await response.json();
    } catch (err) {
      console.warn('[i18n] failed to load', name);
      return null; // 加载失败回退 chrome.i18n，避免整页失去文案
    }
  }

  // 并发 init 的胜负以"最后发起者"为准：重叠调用时最后 resolve 的旧调用不得覆盖新状态
  let generation = 0;

  async function init() {
    const myGeneration = ++generation;
    // preference 与 messages 先落到局部变量，确认仍最新后一次性写入共享状态。
    // 存储读取失败（reject）不能向上抛：popup/dashboard/blocked 顶层 await init，
    // 抛错会让整个 module 停掉，按钮和表单都不绑定；按 browser 偏好回退。
    let nextPreference = 'browser';
    try {
      const stored = await chrome.storage.local.get(STORAGE_KEY);
      nextPreference = normalize(stored[STORAGE_KEY]);
    } catch (err) {
      console.warn('[i18n] failed to read storage preference, falling back to browser language', err);
    }
    const nextMessages = nextPreference === 'browser' ? null : await loadMessages(nextPreference);
    if (myGeneration !== generation) return; // 已被更新的 init 取代，丢弃旧结果
    preference = nextPreference;
    messages = nextMessages;
  }

  const getPreference = () => preference;

  async function setPreference(value) {
    if (!PREFERENCES.includes(value)) throw new Error(`Unknown language preference: ${value}`);
    await chrome.storage.local.set({ [STORAGE_KEY]: value });
    await init();
  }

  const categoryKeys = {
    学习: 'categoryLearning',
    工作: 'categoryWork',
    开发: 'categoryDevelopment',
    社交: 'categorySocial',
    资讯: 'categoryNews',
    搜索: 'categorySearch',
    购物: 'categoryShopping',
    娱乐: 'categoryEntertainment',
    工具: 'categoryTools',
    其他: 'categoryOther',
  };

  function category(value) {
    return t(categoryKeys[value] || 'categoryOther');
  }

  function formatDuration(ms, direction) {
    if (ms <= 0) return t('durationZero');
    const totalMin = direction === 'up' ? Math.ceil(ms / 60000) : Math.floor(ms / 60000);
    if (totalMin < 1) return t('durationUnderMinute');
    const hours = Math.floor(totalMin / 60);
    const minutes = totalMin % 60;
    if (hours > 0) {
      return minutes > 0
        ? t('durationHoursMinutes', [String(hours), String(minutes)])
        : t('durationHours', String(hours));
    }
    return t('durationMinutes', String(totalMin));
  }

  function apply() {
    document.documentElement.lang = locale();
    for (const element of document.querySelectorAll('[data-i18n]')) {
      const message = t(element.dataset.i18n);
      if (message) element.textContent = message;
    }
    for (const element of document.querySelectorAll('[data-i18n-attr]')) {
      for (const entry of element.dataset.i18nAttr.split(' ')) {
        const [attribute, key] = entry.split(':');
        const message = t(key);
        if (message) element.setAttribute(attribute, message);
      }
    }
  }

  return { init, getPreference, setPreference, t, locale, isChinese, category, formatDuration, apply };
})();
