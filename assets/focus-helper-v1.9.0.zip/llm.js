'use strict';

// 专注助手：LLM 配置与偏好分析（classic script，由 background 顶部 importScripts 加载）。
// 唯一顶层名 FocusLlm。密钥只存 chrome.storage.local、只在本 SW 内使用，
// 请求只在 SW 发起，密钥与请求头不写入日志。
const FocusLlm = (() => {
  const CONFIG_KEY = 'llmConfig';
  const ANALYSIS_KEY = 'latestAnalysis';
  const OVERRIDES_KEY = 'categoryOverrides';
  const REQUEST_TIMEOUT_MS = 30000;
  const ANALYSIS_DAYS = 7;
  const ANALYSIS_LIMIT = 40;
  const MAX_INSIGHTS = 5;
  const DEFAULT_BASE_URL = 'https://api.deepseek.com';
  const DEFAULT_MODEL_NAME = 'deepseek-flash';

  // 旧版默认模型名在读取时迁移，其他自定义模型名保持不变
  function normalizeModelName(value) {
    return value === 'deepseek-v4.1-flash' ? DEFAULT_MODEL_NAME : value;
  }

  function isLoopbackHost(hostname) {
    return hostname === 'localhost' || hostname === '127.0.0.1' || hostname === '[::1]' || hostname === '::1';
  }

  // http/https only；拒绝用户名密码、query、hash；http 仅环回地址；
  // 末尾不是 /chat/completions 时自动补全。
  function normalizeBaseUrl(input) {
    if (typeof input !== 'string') return null;
    const s = input.trim();
    if (!s) return null;
    let u;
    try {
      u = new URL(s);
    } catch (err) {
      return null;
    }
    if (u.protocol !== 'https:' && u.protocol !== 'http:') return null;
    if (u.username || u.password) return null;
    if (u.search || u.hash) return null;
    if (u.protocol === 'http:' && !isLoopbackHost(u.hostname)) return null;
    let path = u.pathname.replace(/\/+$/, '');
    if (!path.endsWith('/chat/completions')) path += '/chat/completions';
    return `${u.origin}${path}`;
  }

  async function loadConfig() {
    const raw = await chrome.storage.local.get(CONFIG_KEY);
    const c = raw[CONFIG_KEY] && typeof raw[CONFIG_KEY] === 'object' ? raw[CONFIG_KEY] : {};
    return {
      baseUrl: typeof c.baseUrl === 'string' && c.baseUrl ? c.baseUrl : DEFAULT_BASE_URL,
      modelName: normalizeModelName(typeof c.modelName === 'string' && c.modelName ? c.modelName : DEFAULT_MODEL_NAME),
      apiKey: typeof c.apiKey === 'string' ? c.apiKey : '',
    };
  }

  // 对外永不返回 apiKey
  function publicConfig(c) {
    return { baseUrl: c.baseUrl, modelName: c.modelName, hasApiKey: Boolean(c.apiKey) };
  }

  async function getConfig() {
    return publicConfig(await loadConfig());
  }

  // apiKey 非空才替换；空白字符串保留旧密钥。baseUrl/modelName 提供非空时校验替换。
  async function saveConfig(msg) {
    const cur = await loadConfig();
    if (msg && typeof msg.baseUrl === 'string' && msg.baseUrl.trim()) {
      const normalized = normalizeBaseUrl(msg.baseUrl);
      if (!normalized) {
        throw new Error(FocusI18n.t('invalidBaseUrl'));
      }
      cur.baseUrl = normalized;
    }
    if (msg && typeof msg.modelName === 'string' && msg.modelName.trim()) {
      cur.modelName = normalizeModelName(msg.modelName.trim());
    }
    if (msg && typeof msg.apiKey === 'string' && msg.apiKey.trim()) {
      cur.apiKey = msg.apiKey.trim();
    }
    await chrome.storage.local.set({ [CONFIG_KEY]: cur });
    return publicConfig(cur);
  }

  async function clearApiKey() {
    const cur = await loadConfig();
    cur.apiKey = '';
    await chrome.storage.local.set({ [CONFIG_KEY]: cur });
    return publicConfig(cur);
  }

  function httpErrorMessage(status) {
    if (status === 400) return FocusI18n.t('http400');
    if (status === 401) return FocusI18n.t('http401');
    if (status === 403) return FocusI18n.t('http403');
    if (status === 404) return FocusI18n.t('http404');
    if (status === 429) return FocusI18n.t('http429');
    if (status >= 500) return FocusI18n.t('httpServer', String(status));
    return FocusI18n.t('httpFailure', String(status));
  }

  // DeepSeek 使用官方推理参数；其他 OpenAI 兼容服务仍发送最小请求体，避免不支持字段
  async function postChat(config, messages) {
    const url = normalizeBaseUrl(config.baseUrl);
    const body = { model: config.modelName, messages };
    if (url && new URL(url).hostname === 'api.deepseek.com') {
      body.reasoning_effort = 'high';
      body.thinking = { type: 'enabled' };
      body.stream = false;
    }
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${config.apiKey}` },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
    }).catch(() => {
      throw new Error(FocusI18n.t('networkError'));
    });
    if (!res.ok) throw new Error(httpErrorMessage(res.status));
    return res.json();
  }

  function requireReadyConfig(config) {
    if (!config.baseUrl) throw new Error(FocusI18n.t('needBaseUrl'));
    if (!config.modelName) throw new Error(FocusI18n.t('needModelName'));
    if (!config.apiKey) throw new Error(FocusI18n.t('needApiKey'));
  }

  // 最小 ping，不含任何浏览活动
  async function testConnection() {
    const config = await loadConfig();
    requireReadyConfig(config);
    await postChat(config, [{ role: 'user', content: 'ping' }]);
    return FocusI18n.t('connectionSuccess');
  }

  // 剥离 Markdown 围栏并提取 JSON 对象；失败返回 null
  function extractJson(text) {
    if (typeof text !== 'string') return null;
    let s = text.trim();
    s = s.replace(/^```(?:json)?\s*/i, '').replace(/\s*```\s*$/i, '');
    const start = s.indexOf('{');
    const end = s.lastIndexOf('}');
    if (start < 0 || end <= start) return null;
    try {
      return JSON.parse(s.slice(start, end + 1));
    } catch (err) {
      return null;
    }
  }

  function buildAnalysisPrompt(activities) {
    const list = activities.map((a) => ({
      id: a.id,
      domain: a.domain,
      title: a.title,
      durationMinutes: Math.round(a.durationMs / 60000),
    }));
    return [
      {
        role: 'system',
        content: FocusI18n.t('analysisPromptSystem'),
      },
      {
        role: 'user',
        content: [
          FocusI18n.t('analysisPromptCategories', FocusAnalytics.CATEGORIES.join('、')),
          FocusI18n.t('analysisPromptJsonOnly'),
          FocusI18n.t('analysisPromptJsonFormat'),
          FocusI18n.t('analysisPromptInsightsLimit', String(MAX_INSIGHTS)),
          '',
          FocusI18n.t('analysisPromptActivityList'),
          JSON.stringify(list),
        ].join('\n'),
      },
    ];
  }

  function normalizeInsights(list) {
    if (!Array.isArray(list)) return [];
    return list
      .slice(0, MAX_INSIGHTS)
      .filter((it) => it && typeof it === 'object' && typeof it.title === 'string')
      .map((it) => ({
        title: it.title,
        detail: typeof it.detail === 'string' ? it.detail : '',
        suggestion: typeof it.suggestion === 'string' ? it.suggestion : '',
      }));
  }

  function extractContent(resp) {
    if (resp && typeof resp === 'object' && resp.choices && Array.isArray(resp.choices)) {
      const first = resp.choices[0];
      if (first && first.message && typeof first.message.content === 'string') return first.message.content;
    }
    return '';
  }

  async function getLatestAnalysis() {
    const raw = await chrome.storage.local.get(ANALYSIS_KEY);
    return raw[ANALYSIS_KEY] && typeof raw[ANALYSIS_KEY] === 'object' ? raw[ANALYSIS_KEY] : null;
  }

  // 防重复分析：Web Locks ifAvailable 的真实语义是锁被占用时仍调用回调、但 lock 为 null，
  // 据此立即明确拒绝；不依赖匹配浏览器错误文案。
  // 输入读取与结果写入用短 LOCK_NAME 包住（与 tick/clearAnalytics 的锁顺序一致，不会死锁）；
  // postChat 等网络请求绝不进 LOCK_NAME。
  // 分类时长一律本地重算，绝不信模型返回的分钟数。
  async function analyze() {
    return navigator.locks.request(LLM_LOCK_NAME, { ifAvailable: true }, async (lock) => {
      if (!lock) throw new Error(FocusI18n.t('analysisInProgress'));
      const config = await loadConfig();
      requireReadyConfig(config);
      const activities = await navigator.locks.request(LOCK_NAME, () =>
        FocusAnalytics.topActivities(ANALYSIS_DAYS, ANALYSIS_LIMIT)
      );
      if (activities.length === 0) throw new Error(FocusI18n.t('noActivitiesToAnalyze'));
      const resp = await postChat(config, buildAnalysisPrompt(activities));
      const parsed = extractJson(extractContent(resp));

      const summary = parsed && typeof parsed.summary === 'string' && parsed.summary.trim() ? parsed.summary.trim() : '';
      const hasClass = Boolean(parsed && Array.isArray(parsed.classifications));
      if (!summary && !hasClass) throw new Error(FocusI18n.t('invalidModelResponse'));

      const byId = new Map();
      if (hasClass) {
        for (const c of parsed.classifications) {
          if (c && typeof c === 'object' && typeof c.id === 'string' && typeof c.category === 'string') {
            byId.set(c.id, c.category);
          }
        }
      }
      const vocab = new Set(FocusAnalytics.CATEGORIES);
      const classifiedActivities = [];
      const catTotals = new Map();
      for (const a of activities) {
        if (!byId.has(a.id)) continue;
        const rawCategory = byId.get(a.id);
        const category = vocab.has(rawCategory) ? rawCategory : '其他';
        classifiedActivities.push({
          domain: a.domain,
          title: a.title,
          category,
          durationMs: a.durationMs,
          lastTs: a.lastTs,
        });
        catTotals.set(category, (catTotals.get(category) || 0) + a.durationMs);
      }
      const categoryStats = FocusAnalytics.CATEGORIES
        .map((category) => ({ category, durationMs: catTotals.get(category) || 0 }))
        .filter((e) => e.durationMs > 0)
        .sort((a, b) => b.durationMs - a.durationMs);

      const analysis = {
        createdAt: Date.now(),
        modelName: config.modelName,
        rangeDays: ANALYSIS_DAYS,
        summary: summary || FocusI18n.t('noModelSummary'),
        insights: normalizeInsights(parsed ? parsed.insights : null),
        categoryStats,
        classifiedActivities,
      };
      await navigator.locks.request(LOCK_NAME, async () => {
        // 分类覆盖按「域名|标题」累积：只写本次命中的键，未涉及的旧项原样保留。
        // 读取与写入同在 LOCK_NAME 内并落在同一次 set，避免并发分析读到半套数据。
        const overrides = await FocusAnalytics.loadCategoryOverrides();
        const merged = Object.assign({}, overrides);
        for (const a of classifiedActivities) {
          merged[FocusAnalytics.activityCategoryKey(a.domain, a.title)] = a.category;
        }
        await chrome.storage.local.set({ [ANALYSIS_KEY]: analysis, [OVERRIDES_KEY]: merged });
      });
      return analysis;
    });
  }

  return { getConfig, saveConfig, clearApiKey, testConnection, analyze, getLatestAnalysis };
})();
