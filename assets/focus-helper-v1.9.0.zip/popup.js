'use strict';

await FocusI18n.init();
FocusI18n.apply();
const { t } = FocusI18n;

const els = {
  refreshBtn: document.getElementById('refresh-btn'),
  languageSelect: document.getElementById('language-select'),
  languageStatus: document.getElementById('language-status'),
  currentPanel: document.getElementById('current-panel'),
  form: document.getElementById('add-form'),
  domainInput: document.getElementById('domain-input'),
  manualPicker: document.getElementById('manual-time-picker'),
  statusEl: document.getElementById('form-status'),
  loadingEl: document.getElementById('loading'),
  listEl: document.getElementById('rule-list'),
  emptyTip: document.getElementById('empty-tip'),
  todayTotal: document.getElementById('today-total'),
  openDashboardBtn: document.getElementById('open-dashboard-btn'),
};

function setStatus(message, isError) {
  els.statusEl.textContent = message;
  els.statusEl.classList.toggle('error', Boolean(isError));
}

// 手动选择语言后重新加载页面，让本次页面内已生成的文案也换成新语言；
// 保存失败时回填已存偏好，避免下拉框显示一个并未落盘的值
els.languageSelect.value = FocusI18n.getPreference();

els.languageSelect.addEventListener('change', async () => {
  els.languageSelect.disabled = true;
  try {
    await FocusI18n.setPreference(els.languageSelect.value);
    location.reload();
  } catch (err) {
    els.languageSelect.value = FocusI18n.getPreference();
    els.languageSelect.disabled = false;
    // 提示紧跟顶栏：规则列表很长时页尾的 #form-status 在可视区外，且它属于域名输入框的描述
    els.languageStatus.textContent = t('languageSaveFailed', err && err.message ? err.message : err);
  }
});

// 已用向下取整、剩余向上取整；支持小时与不足 1 分钟的友好显示
function formatDuration(ms, direction) {
  return FocusI18n.formatDuration(ms, direction);
}

function formatClock(totalSeconds) {
  const total = Math.max(0, Math.floor(totalSeconds));
  const hh = String(Math.floor(total / 3600)).padStart(2, '0');
  const mm = String(Math.floor((total % 3600) / 60)).padStart(2, '0');
  const ss = String(total % 60).padStart(2, '0');
  return `${hh}:${mm}:${ss}`;
}

// ---------- 时间滚轮：小时/分钟/秒三列 ----------

// 与 popup.css 的 --item-height 保持一致，用于把滚动位置换算成选中下标
const ITEM_HEIGHT = 36;
// 小时列 0–24：24 表示 24:00:00，此时分钟和秒锁定为 0
const MAX_PICKER_SECONDS = 86400;
const TIME_UNITS = [
  { key: 'h', label: t('unitHours'), short: t('unitHoursShort'), count: 25 },
  { key: 'm', label: t('unitMinutes'), short: t('unitMinutesShort'), count: 60 },
  { key: 's', label: t('unitSeconds'), short: t('unitSecondsShort'), count: 60 },
];
const MAX_PICKER_HOURS = TIME_UNITS[0].count - 1;

function clampInt(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

// 单列滚轮：选中下标是真值来源，ARIA 属性与滚动位置都从它派生
function createTimeColumn({ id, unit, onChange }) {
  const column = document.createElement('div');
  column.className = 'time-picker-column';

  const scroller = document.createElement('div');
  scroller.className = 'time-picker-scroll';
  scroller.id = id;
  scroller.tabIndex = 0;
  scroller.setAttribute('role', 'listbox');
  scroller.setAttribute('aria-label', unit.label);
  scroller.setAttribute('aria-disabled', 'false');

  const options = [];
  for (let value = 0; value < unit.count; value += 1) {
    const option = document.createElement('button');
    option.type = 'button';
    option.id = `${id}-${value}`;
    option.className = 'time-picker-option';
    option.tabIndex = -1;
    option.dataset.value = String(value);
    option.setAttribute('role', 'option');
    option.setAttribute('aria-posinset', String(value + 1));
    option.setAttribute('aria-setsize', String(unit.count));
    option.setAttribute('aria-selected', 'false');
    option.textContent = String(value).padStart(2, '0');
    scroller.appendChild(option);
    options.push(option);
  }

  const band = document.createElement('span');
  band.className = 'time-picker-band';
  band.setAttribute('aria-hidden', 'true');
  column.append(scroller, band);

  const maxIndex = unit.count - 1;
  let index = 0;
  let disabled = false;
  let drag = null;
  let swallowClick = false;

  function paint(next) {
    options[index].setAttribute('aria-selected', 'false');
    index = next;
    options[index].setAttribute('aria-selected', 'true');
    scroller.setAttribute('aria-activedescendant', options[index].id);
  }

  // 同步选中、微任务里只落最后一次定位：既兼容 fieldset 还没被挂载时的初始化
  // （未挂载时写 scrollTop 不生效），也让连续键盘/点击不会用旧任务覆盖新选择
  function scrollToIndex(next) {
    queueMicrotask(() => {
      if (index !== next) return;
      scroller.scrollTo({ top: next * ITEM_HEIGHT, behavior: 'instant' });
    });
  }

  function select(next) {
    if (disabled) return;
    const target = clampInt(next, 0, maxIndex);
    paint(target);
    scrollToIndex(target);
    // 用户改动后通知外部（如小时列驱动上下限）；setValue 回填不走这里，避免递归
    if (onChange) onChange();
  }

  // 滚轮滚动（滚轮/触控/拖动）过程中同步选中项，避免 ARIA 与实际可见状态脱节
  scroller.addEventListener('scroll', () => {
    if (disabled) return;
    const nearest = clampInt(Math.round(scroller.scrollTop / ITEM_HEIGHT), 0, maxIndex);
    if (nearest === index) return;
    paint(nearest);
    if (onChange) onChange();
  });

  scroller.addEventListener('keydown', (event) => {
    if (disabled) return;
    let next;
    switch (event.key) {
      case 'ArrowUp': next = index - 1; break;
      case 'ArrowDown': next = index + 1; break;
      case 'PageUp': next = index - 5; break;
      case 'PageDown': next = index + 5; break;
      case 'Home': next = 0; break;
      case 'End': next = maxIndex; break;
      default: return;
    }
    event.preventDefault();
    select(next);
  });

  // 鼠标拖动滚动；触屏保留原生 pan-y，交给浏览器
  scroller.addEventListener('pointerdown', (event) => {
    if (disabled) return;
    scroller.focus({ preventScroll: true });
    swallowClick = false;
    if (event.pointerType !== 'mouse' || event.button !== 0) return;
    drag = {
      pointerId: event.pointerId,
      startY: event.clientY,
      startTop: scroller.scrollTop,
      option: event.target.closest('.time-picker-option'),
      moved: false,
    };
    scroller.setPointerCapture(event.pointerId);
    // 拖动期间关闭吸附，否则每次 scrollTop 赋值都会被立刻重新吸附
    scroller.style.scrollSnapType = 'none';
  });

  scroller.addEventListener('pointermove', (event) => {
    if (!drag || event.pointerId !== drag.pointerId) return;
    event.preventDefault();
    const delta = event.clientY - drag.startY;
    if (Math.abs(delta) > 3) drag.moved = true;
    scroller.scrollTop = drag.startTop - delta;
  });

  function endDrag(event) {
    if (!drag || event.pointerId !== drag.pointerId) return;
    const { moved, option } = drag;
    drag = null;
    if (scroller.hasPointerCapture(event.pointerId)) scroller.releasePointerCapture(event.pointerId);
    scroller.style.scrollSnapType = '';
    // Pointer Capture 会把后续 pointerup/click 的 target 换成 scroller，按下的选项只能在 pointerdown 记住；
    // 未拖动时以它为准，避免被旧 scrollTop 覆盖，并吞掉这次已经处理过的 click
    swallowClick = moved || Boolean(option);
    if (!moved && option) select(Number(option.dataset.value));
    else select(Math.round(scroller.scrollTop / ITEM_HEIGHT));
  }

  scroller.addEventListener('pointerup', endDrag);
  scroller.addEventListener('pointercancel', endDrag);
  scroller.addEventListener('lostpointercapture', endDrag);

  scroller.addEventListener('click', (event) => {
    const moved = swallowClick;
    swallowClick = false;
    if (disabled) return;
    const option = event.target.closest('.time-picker-option');
    if (!option || moved) return;
    select(Number(option.dataset.value));
  });

  function setDisabled(next) {
    if (disabled === next) return;
    disabled = next;
    column.classList.toggle('is-disabled', disabled);
    scroller.setAttribute('aria-disabled', String(disabled));
    scroller.tabIndex = disabled ? -1 : 0;
    for (const option of options) option.disabled = disabled;
  }

  paint(0);

  return {
    element: column,
    getValue: () => index,
    // 回填不受禁用影响：24:00:00 时分钟/秒仍需能显示 00
    setValue: (value) => {
      const target = clampInt(value, 0, maxIndex);
      paint(target);
      scrollToIndex(target);
    },
    setDisabled,
  };
}

function createTimePicker({ id, seconds = 1800, label = t('dailyLimit') }) {
  const fieldset = document.createElement('fieldset');
  fieldset.className = 'time-picker';
  fieldset.id = id;
  fieldset.name = id;

  const legend = document.createElement('legend');
  legend.textContent = label;

  const columnsWrap = document.createElement('div');
  columnsWrap.className = 'time-picker-columns';
  const unitsRow = document.createElement('div');
  unitsRow.className = 'time-picker-units';
  unitsRow.setAttribute('aria-hidden', 'true');

  const columns = TIME_UNITS.map((unit) => {
    const column = createTimeColumn({
      id: `${id}-${unit.key}`,
      unit,
      onChange: unit.key === 'h' ? syncBounds : null,
    });
    columnsWrap.appendChild(column.element);
    const caption = document.createElement('span');
    caption.textContent = unit.short;
    unitsRow.appendChild(caption);
    return column;
  });

  fieldset.append(legend, columnsWrap, unitsRow);

  // 24:00:00 是上限，此时分钟/秒只能是 0 并锁定；回到 0–23 小时恢复可编辑
  function syncBounds() {
    const atMax = columns[0].getValue() === MAX_PICKER_HOURS;
    if (atMax) {
      columns[1].setValue(0);
      columns[2].setValue(0);
    }
    columns[1].setDisabled(atMax);
    columns[2].setDisabled(atMax);
  }

  function setSeconds(total) {
    const rounded = Math.round(Number(total));
    const clamped = clampInt(Number.isFinite(rounded) ? rounded : 1, 1, MAX_PICKER_SECONDS);
    columns[0].setValue(Math.floor(clamped / 3600));
    columns[1].setValue(Math.floor((clamped % 3600) / 60));
    columns[2].setValue(clamped % 60);
    syncBounds();
  }

  function getSeconds() {
    const [h, m, s] = columns.map((column) => column.getValue());
    return clampInt(h * 3600 + m * 60 + s, 1, MAX_PICKER_SECONDS);
  }

  setSeconds(seconds);

  return { element: fieldset, getSeconds, setSeconds };
}

// 手动添加表单的滚轮，默认 30 分钟
const manualTimePicker = createTimePicker({ id: 'manual-minutes', seconds: 1800, label: t('dailyLimit') });
els.manualPicker.appendChild(manualTimePicker.element);

function render(state) {
  // 重绘后恢复用户展开的规则设置
  const openSet = new Set();
  for (const li of els.listEl.children) {
    const details = li.querySelector('details');
    if (details && details.open) openSet.add(li.dataset.domain);
  }
  els.listEl.textContent = '';
  els.emptyTip.hidden = state.rules.length > 0;
  for (const rule of state.rules) {
    els.listEl.appendChild(renderRuleItem(rule, state.activeDomain, openSet));
  }
  renderCurrentPanel(state);
  els.loadingEl.hidden = true;
}

function renderCurrentPanel(state) {
  const panel = els.currentPanel;
  panel.textContent = '';
  const site = state.currentSite;
  if (!site) {
    const guide = document.createElement('p');
    guide.className = 'current-guide';
    guide.textContent = t('currentGuide');
    panel.appendChild(guide);
    return;
  }

  const title = document.createElement('p');
  title.className = 'current-domain';
  title.textContent = site.domain;

  const rule = site.ruleDomain ? state.rules.find((r) => r.domain === site.ruleDomain) : null;
  if (rule) {
    const badge = document.createElement('span');
    badge.className = 'badge';
    badge.textContent = t('alreadyInRules');
    const head = document.createElement('div');
    head.className = 'current-head';
    head.append(title, badge);
    const meta = document.createElement('p');
    meta.className = 'current-meta';
    meta.textContent = rule.expired
      ? t('currentExpired')
      : t('currentRemaining', [formatDuration(rule.remainingMs, 'up'), formatClock(rule.limitSeconds)]);
    panel.append(head, meta);
    return;
  }

  const form = document.createElement('form');
  form.className = 'quick-form';
  form.action = '#';
  form.method = 'post';
  const picker = createTimePicker({ id: 'quick-minutes', seconds: 1800, label: t('dailyLimit') });
  const btn = document.createElement('button');
  btn.type = 'submit';
  btn.className = 'btn primary';
  btn.textContent = t('addThisSite');
  form.append(picker.element, btn);

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    btn.disabled = true;
    btn.textContent = t('adding');
    try {
      const res = await chrome.runtime.sendMessage({
        type: 'addRule',
        domain: site.domain,
        limitSeconds: picker.getSeconds(),
      });
      if (!res || !res.ok) {
        setStatus(t('addFailed', res ? res.error : t('unknownError')), true);
        return;
      }
      setStatus(t('addedDomain', site.domain), false);
      render(res.state);
    } catch (err) {
      setStatus(t('addFailed', err && err.message ? err.message : err), true);
    } finally {
      btn.disabled = false;
      btn.textContent = t('addThisSite');
    }
  });

  panel.append(title, form);
}

function renderRuleItem(rule, activeDomain, openSet) {
  const li = document.createElement('li');
  li.className = 'rule';
  li.dataset.domain = rule.domain;
  const isActive = !rule.expired && activeDomain === rule.domain;
  if (rule.expired) li.classList.add('expired');
  else if (isActive) li.classList.add('active');

  const head = document.createElement('div');
  head.className = 'rule-head';
  const name = document.createElement('span');
  name.className = 'rule-domain';
  name.textContent = rule.domain;
  const status = document.createElement('span');
  status.className = 'rule-status';
  status.textContent = rule.expired ? t('statusExpired') : t(isActive ? 'statusTiming' : 'statusNotTiming');
  head.append(name, status);

  const remaining = document.createElement('p');
  remaining.className = 'rule-remaining';
  remaining.textContent = rule.expired ? t('todayExpired') : t('remainingDuration', formatDuration(rule.remainingMs, 'up'));

  const meta = document.createElement('p');
  meta.className = 'rule-meta';
  meta.textContent = t('usedLimit', [formatDuration(rule.usedMs, 'down'), formatClock(rule.limitSeconds)]);

  const limitMinutes = rule.limitSeconds / 60;
  const progress = document.createElement('progress');
  progress.max = limitMinutes;
  progress.value = Math.min(limitMinutes, rule.usedMs / 60000);
  progress.setAttribute('aria-label', t('progressAria', [rule.domain, formatDuration(rule.usedMs, 'down'), formatClock(rule.limitSeconds)]));

  const details = document.createElement('details');
  details.className = 'rule-settings';
  details.name = 'rule-settings';
  if (openSet.has(rule.domain)) details.open = true;
  const summary = document.createElement('summary');
  summary.textContent = t('ruleSettings');

  const editForm = document.createElement('form');
  editForm.className = 'rule-edit';
  editForm.action = '#';
  editForm.method = 'post';
  const picker = createTimePicker({
    id: `limit-${rule.domain}`,
    seconds: rule.limitSeconds,
    label: t('dailyLimit'),
  });
  const actions = document.createElement('div');
  actions.className = 'rule-actions';
  const saveBtn = document.createElement('button');
  saveBtn.type = 'submit';
  saveBtn.className = 'btn primary';
  saveBtn.textContent = t('save');
  const delBtn = document.createElement('button');
  delBtn.type = 'button';
  delBtn.className = 'btn danger';
  delBtn.textContent = t('delete');
  actions.append(saveBtn, delBtn);
  editForm.append(picker.element, actions);
  details.append(summary, editForm);
  // 收起时不给 details 内容排版，滚动位置丢失，展开后按规则值重新回填一次
  details.addEventListener('toggle', () => {
    if (details.open) picker.setSeconds(rule.limitSeconds);
  });

  li.append(head, remaining, meta, progress, details);

  editForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    saveBtn.disabled = true;
    try {
      const res = await chrome.runtime.sendMessage({
        type: 'updateRule',
        domain: rule.domain,
        limitSeconds: picker.getSeconds(),
      });
      if (!res || !res.ok) {
        setStatus(t('saveFailed', res ? res.error : t('unknownError')), true);
        return;
      }
      setStatus(t('savedLimit', rule.domain), false);
      render(res.state);
    } catch (err) {
      setStatus(t('saveFailed', err && err.message ? err.message : err), true);
    } finally {
      saveBtn.disabled = false;
    }
  });

  delBtn.addEventListener('click', async () => {
    delBtn.disabled = true;
    try {
      const res = await chrome.runtime.sendMessage({ type: 'removeRule', domain: rule.domain });
      if (!res || !res.ok) {
        setStatus(t('deleteFailed', res ? res.error : t('unknownError')), true);
        return;
      }
      setStatus(t('deletedDomain', rule.domain), false);
      render(res.state);
    } catch (err) {
      setStatus(t('deleteFailed', err && err.message ? err.message : err), true);
    } finally {
      delBtn.disabled = false;
    }
  });

  return li;
}

els.form.addEventListener('submit', async (e) => {
  e.preventDefault();
  els.domainInput.removeAttribute('aria-invalid');
  if (!els.form.checkValidity()) {
    els.form.reportValidity();
    return;
  }
  const submitBtn = els.form.querySelector('button[type="submit"]');
  submitBtn.disabled = true;
  try {
    const res = await chrome.runtime.sendMessage({
      type: 'addRule',
      domain: els.domainInput.value,
      limitSeconds: manualTimePicker.getSeconds(),
    });
    if (!res || !res.ok) {
      setStatus(t('addFailed', res ? res.error : t('unknownError')), true);
      els.domainInput.setAttribute('aria-invalid', 'true');
      return;
    }
    setStatus(t('addedDomain', els.domainInput.value.trim()), false);
    els.domainInput.value = '';
    render(res.state);
  } catch (err) {
    setStatus(t('addFailed', err && err.message ? err.message : err), true);
  } finally {
    submitBtn.disabled = false;
  }
});

els.domainInput.addEventListener('input', () => {
  els.domainInput.removeAttribute('aria-invalid');
});

els.refreshBtn.addEventListener('click', async () => {
  els.refreshBtn.disabled = true;
  const ok = await refresh();
  els.refreshBtn.disabled = false;
  if (ok) setStatus('', false);
});

async function refresh() {
  try {
    const res = await chrome.runtime.sendMessage({ type: 'getState' });
    if (res && res.ok) {
      render(res.state);
      return true;
    }
    setStatus(t('readStateFailed', res ? res.error : t('unknownError')), true);
  } catch (err) {
    setStatus(t('readStateFailed', err && err.message ? err.message : err), true);
  }
  els.loadingEl.hidden = true;
  return false;
}

// 今日总耗时单独获取，失败不影响主流程
async function loadTodayTotal() {
  try {
    const res = await chrome.runtime.sendMessage({ type: 'getDashboardData', rangeDays: 1, summaryOnly: true });
    if (res && res.ok) {
      els.todayTotal.textContent = t('todayBrowsing', formatDuration(res.data.totalDurationMs, 'down'));
      els.todayTotal.hidden = false;
    }
  } catch (err) {
    els.todayTotal.hidden = true;
  }
}

els.openDashboardBtn.addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('dashboard.html') });
});

// 直接以标签页打开 popup.html 时跳转到完整统计页；action 弹窗 getCurrent 为 undefined，留在原页
(async () => {
  try {
    const tab = await chrome.tabs.getCurrent();
    if (tab && typeof tab.id === 'number') {
      location.replace('dashboard.html');
      return;
    }
  } catch (err) {
    // 无法判断时保留弹窗行为
  }
  refresh();
  loadTodayTotal();
})();
