'use strict';

const FocusI18n = (() => {
  const t = (key, substitutions) => chrome.i18n.getMessage(key, substitutions);
  const locale = () => chrome.i18n.getUILanguage();
  const isChinese = () => locale().toLowerCase().startsWith('zh');
  const categoryKeys = {
    学习: 'categoryLearning',
    工作: 'categoryWork',
    开发: 'categoryDevelopment',
    社交: 'categorySocial',
    资讯: 'categoryNews',
    搜索: 'categorySearch',
    购物: 'categoryShopping',
    娱乐: 'categoryEntertainment',
    工具: 'categoryTools',
    其他: 'categoryOther',
  };

  function category(value) {
    return t(categoryKeys[value] || 'categoryOther');
  }

  function formatDuration(ms, direction) {
    if (ms <= 0) return t('durationZero');
    const totalMin = direction === 'up' ? Math.ceil(ms / 60000) : Math.floor(ms / 60000);
    if (totalMin < 1) return t('durationUnderMinute');
    const hours = Math.floor(totalMin / 60);
    const minutes = totalMin % 60;
    if (hours > 0) {
      return minutes > 0
        ? t('durationHoursMinutes', [String(hours), String(minutes)])
        : t('durationHours', String(hours));
    }
    return t('durationMinutes', String(totalMin));
  }

  function apply() {
    document.documentElement.lang = locale();
    for (const element of document.querySelectorAll('[data-i18n]')) {
      const message = t(element.dataset.i18n);
      if (message) element.textContent = message;
    }
    for (const element of document.querySelectorAll('[data-i18n-attr]')) {
      for (const entry of element.dataset.i18nAttr.split(' ')) {
        const [attribute, key] = entry.split(':');
        const message = t(key);
        if (message) element.setAttribute(attribute, message);
      }
    }
  }

  return { t, locale, isChinese, category, formatDuration, apply };
})();
