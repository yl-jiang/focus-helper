'use strict';

// 专注助手：网站每日限时（MV3 service worker）
// 业务状态全部落在 chrome.storage（local 持久化 + session 计时片段），
// 不使用全局变量、不使用 setTimeout/setInterval；
// 标签页/窗口/idle/alarm/消息事件统一汇入 tick()，用 Web Locks 串行结算，避免并发竞争。

const ALARM_NAME = 'focus-helper-tick';
const ALARM_PERIOD_MINUTES = 0.5; // 30 秒（Chrome 120+ 最小周期）
const LOCK_NAME = 'focus-helper-tick-lock';
// 分析专用锁：与 LOCK_NAME 独立，清历史按 LLM_LOCK_NAME → LOCK_NAME 顺序获取，防止旧分析复活
const LLM_LOCK_NAME = 'focus-helper-llm-lock';
const DASHBOARD_MENU_ID = 'open-dashboard';
const DNR_ID_BASE = 1000;
const BLOCKED_PATH = '/blocked.html';
const MINUTE_MS = 60 * 1000;
// 单一片段结算上限：alarm 在系统睡眠时停走，醒来会把整段睡眠时长补进一条片段，
// 若不截断会把全天额度一次扣光；正常事件驱动下片段远小于该值。
const MAX_SEGMENT_MS = 10 * 60 * 1000;

const DEFAULT_RULES = [
  { domain: 'bilibili.com', limitMinutes: 30 },
  { domain: 'youtube.com', limitMinutes: 30 },
];

importScripts('i18n.js', 'activity.js', 'llm.js');

// ---------- 基础工具 ----------

function localDateString(ts = Date.now()) {
  const d = new Date(ts);
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${d.getFullYear()}-${m}-${day}`;
}

function domainMatches(hostname, domain) {
  return hostname === domain || hostname.endsWith('.' + domain);
}

// 规范化用户输入：支持粘贴完整 URL、去协议/端口/路径、小写、去开头 www.；
// 不合法返回 null。
function normalizeDomain(input) {
  if (typeof input !== 'string') return null;
  let s = input.trim().toLowerCase();
  if (!s) return null;
  try {
    // 统一走 URL 解析：剥离协议/端口/路径，并把 IDN 转为 punycode
    s = s.includes('://') ? new URL(s).hostname : new URL('http://' + s).hostname;
  } catch (err) {
    return null;
  }
  s = s.replace(/^www\./, '').replace(/\.$/, '');
  if (!s) return null;
  const labels = s.split('.');
  if (labels.length < 2) return null; // 必须是域名而非单词
  const labelRe = /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/;
  for (const label of labels) {
    if (!labelRe.test(label)) return null;
  }
  if (labels[labels.length - 1].length < 2) return null; // TLD 至少 2 位
  if (labels.every((l) => /^\d+$/.test(l))) return null; // 纯数字标签是 IPv4 写法，不是可用域名
  return s;
}

function toLimitMinutes(value) {
  const n = Number(value);
  if (!Number.isInteger(n) || n < 1 || n > 1440) return null;
  return n;
}

function toLimitSeconds(value) {
  const n = Number(value);
  if (!Number.isInteger(n) || n < 1 || n > 86400) return null;
  return n;
}

// 额度真值以秒为准：新规则存 limitSeconds；旧规则只有 limitMinutes，按分钟换算
function limitSecondsOf(rule) {
  return rule.limitSeconds === undefined ? rule.limitMinutes * 60 : rule.limitSeconds;
}

// 兼容旧 UI 的分钟消息：优先读 limitSeconds，缺省时把 limitMinutes 换算成秒
function readLimitSeconds(msg) {
  if (msg.limitSeconds !== undefined) return toLimitSeconds(msg.limitSeconds);
  const limitMinutes = toLimitMinutes(msg.limitMinutes);
  return limitMinutes === null ? null : limitMinutes * 60;
}

// 错误文案跟随调用方实际传的字段，旧 UI 仍看到原来的分钟提示
function limitErrorText(msg) {
  return FocusI18n.t(msg.limitSeconds !== undefined ? 'limitSecondsError' : 'limitMinutesError');
}

// 片段归属的规则域：旧格式片段（无 ruleDomain 字段）回退用 domain；新格式显式 null 表示非规则站
function segmentRuleDomain(segment) {
  return segment.ruleDomain === undefined ? segment.domain : segment.ruleDomain;
}

// ---------- 状态读写 ----------

async function loadState() {
  const raw = await chrome.storage.local.get(['rules', 'date', 'notified']);
  const rules = Array.isArray(raw.rules) ? raw.rules : [];
  const notified = raw.notified && typeof raw.notified === 'object' ? raw.notified : {};
  return { rules, notified, date: typeof raw.date === 'string' ? raw.date : '' };
}

async function buildUiState() {
  const state = await loadState();
  const session = await chrome.storage.session.get(['segment']);
  const site = await getFocusedTabSite();
  let currentSite = null;
  if (site) {
    const rule = state.rules.find((r) => domainMatches(site.hostname, r.domain));
    currentSite = { domain: site.domain, ruleDomain: rule ? rule.domain : null };
  }
  return {
    date: state.date,
    activeDomain: session.segment ? segmentRuleDomain(session.segment) : null,
    currentSite,
    rules: state.rules.map((r) => {
      const limitSeconds = limitSecondsOf(r);
      const limitMs = limitSeconds * 1000;
      const usedMs = Math.min(r.usedMs || 0, limitMs);
      return {
        domain: r.domain,
        limitMinutes: r.limitMinutes,
        limitSeconds,
        usedMs,
        remainingMs: Math.max(0, limitMs - usedMs),
        expired: usedMs >= limitMs,
      };
    }),
  };
}

// ---------- 通知（失败不影响计时与拦截） ----------

async function fireNotifications(rules, notified) {
  const today = localDateString();
  for (const rule of rules) {
    const limitSeconds = limitSecondsOf(rule);
    const limitMs = limitSeconds * 1000;
    const remaining = limitMs - (rule.usedMs || 0);
    const due = [];
    if (remaining <= 0) {
      due.push(['expired', FocusI18n.t('notificationExpired', rule.domain)]);
    } else {
      // 临近提醒仅在阈值小于总额度时发送（如限额 1 分钟时不发"剩余 5 分钟"）
      if (limitSeconds > 5 * 60 && remaining <= 5 * MINUTE_MS) {
        due.push(['m5', FocusI18n.t('notificationFiveMinutes', rule.domain)]);
      }
      if (limitSeconds > 60 && remaining <= MINUTE_MS) {
        due.push(['m1', FocusI18n.t('notificationOneMinute', rule.domain)]);
      }
    }
    if (due.length === 0) continue;
    const flags = Array.isArray(notified[rule.domain]) ? notified[rule.domain] : (notified[rule.domain] = []);
    for (const [kind, message] of due) {
      if (flags.includes(kind)) continue;
      flags.push(kind);
      try {
        await chrome.notifications.create(`focus-helper:${today}:${rule.domain}:${kind}`, {
          type: 'basic',
          iconUrl: chrome.runtime.getURL('icon.png'),
          title: FocusI18n.t('extensionName'),
          message,
        });
      } catch (err) {
        // 通知失败（如系统通知中心不可用）静默忽略，拦截与计时不依赖通知
      }
    }
  }
}

// ---------- 到期拦截：DNR 动态规则 + 重定向已打开标签页 ----------

async function syncBlockingRules(expiredDomains) {
  const signature = expiredDomains.join('|');
  const session = await chrome.storage.session.get(['dnrSignature']);
  if (session.dnrSignature === signature) return; // 无变化不写，避免每 30 秒空转
  const existing = await chrome.declarativeNetRequest.getDynamicRules();
  const removeRuleIds = existing.map((r) => r.id);
  const addRules = expiredDomains.map((domain, index) => ({
    id: DNR_ID_BASE + index,
    priority: 1,
    action: {
      type: 'redirect',
      redirect: { extensionPath: BLOCKED_PATH },
    },
    condition: {
      // requestDomains 匹配该域名及其子域名，与路径/query/端口无关（Chrome 101+）
      requestDomains: [domain],
      resourceTypes: ['main_frame'],
    },
  }));
  await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds, addRules });
  await chrome.storage.session.set({ dnrSignature: signature });
}

// 把已打开的目标标签页同步重定向到 blocked 页，防止已打开 SPA 停留在站内绕过拦截
async function redirectOpenTabs(expiredDomains) {
  if (expiredDomains.length === 0) return;
  const blockedBase = chrome.runtime.getURL(BLOCKED_PATH);
  let tabs;
  try {
    tabs = await chrome.tabs.query({});
  } catch (err) {
    return;
  }
  for (const tab of tabs) {
    if (!tab.url || tab.id === undefined) continue;
    let hostname = '';
    try {
      const u = new URL(tab.url);
      if (u.protocol !== 'http:' && u.protocol !== 'https:') continue;
      hostname = u.hostname.toLowerCase();
    } catch (err) {
      continue;
    }
    const hit = expiredDomains.find((d) => domainMatches(hostname, d));
    if (!hit || tab.url.startsWith(blockedBase)) continue;
    try {
      await chrome.tabs.update(tab.id, { url: `${blockedBase}?site=${encodeURIComponent(hit)}` });
    } catch (err) {
      // 标签页可能正在关闭，忽略
    }
  }
}

// ---------- 当前是否应计时 ----------

// 读取前台 focused 窗口 active 标签页的可匹配站点信息；内置页/非法地址返回 null。
// 只做读取，不判断是否计时——计时判断（locked 暂停）在 resolveActiveDomain。
async function getFocusedTabSite() {
  const session = await chrome.storage.session.get(['focusWindowId']);
  const windowId = session.focusWindowId;
  if (typeof windowId !== 'number' || windowId === chrome.windows.WINDOW_ID_NONE) return null;
  let tabs;
  try {
    tabs = await chrome.tabs.query({ windowId, active: true });
  } catch (err) {
    return null;
  }
  const tab = tabs[0];
  if (!tab || !tab.url) return null;
  try {
    const u = new URL(tab.url);
    if (u.protocol !== 'http:' && u.protocol !== 'https:') return null;
    const hostname = u.hostname.toLowerCase();
    const domain = normalizeDomain(hostname);
    if (!domain) return null;
    const title = typeof tab.title === 'string' && tab.title.trim() ? tab.title.trim() : domain;
    return { hostname, domain, title, url: u.href };
  } catch (err) {
    return null;
  }
}

// 返回新的计时片段（domain 保留子域用于活动统计，ruleDomain 用于父规则额度，非规则站为 null）
async function resolveActiveSegment(rules) {
  // 锁屏必须暂停；无键鼠操作（idle）不暂停——视频观看场景页面仍在前台
  const idle = await chrome.idle.queryState(15);
  if (idle === 'locked') return null;
  const site = await getFocusedTabSite();
  if (!site) return null;
  const rule = rules.find((r) => domainMatches(site.hostname, r.domain));
  return { domain: site.domain, title: site.title, ruleDomain: rule ? rule.domain : null, url: site.url };
}

// ---------- 统一结算入口 ----------

async function tick() {
  try {
    await navigator.locks.request(LOCK_NAME, async () => {
      const now = Date.now();
      const today = localDateString(now);
      const state = await loadState();
      const session = await chrome.storage.session.get(['segment']);
      let dirty = false;

      // 1. 本地日历日跨日重置必须先于结算：重置只清掉昨日已落盘用量，
      //    今日 0 点后才开始的新一天计时不应被抹掉
      if (state.date !== today) {
        for (const rule of state.rules) rule.usedMs = 0;
        state.notified = {};
        state.date = today;
        dirty = true;
      }

      // 2. 结算未完成的计时片段；effectiveStart 截到今日 0 点，只把今日部分计入今日。
      //    规则站累计父规则额度，规则外网站只记活动；elapsed 两者共用同一口径
      let settled = null;
      const segment = session.segment;
      if (segment && typeof segment.startTs === 'number' && typeof segment.domain === 'string') {
        const midnight = new Date(now);
        midnight.setHours(0, 0, 0, 0);
        const effectiveStart = Math.max(segment.startTs, midnight.getTime(), now - MAX_SEGMENT_MS);
        const elapsed = Math.max(0, now - effectiveStart);
        if (elapsed > 0) {
          const rule = state.rules.find((r) => r.domain === segmentRuleDomain(segment));
          if (rule) {
            const limitMs = limitSecondsOf(rule) * 1000;
            rule.usedMs = Math.min(limitMs, (rule.usedMs || 0) + elapsed);
            dirty = true;
          }
          settled = { segment, elapsed, effectiveStart };
        }
      }

      // 3. 决定当前是否继续计时（同一时刻至多一个片段，同站多标签页天然共享额度）
      const active = await resolveActiveSegment(state.rules);
      const newSegment = active ? { ...active, startTs: now } : null;

      // 4. 提醒阈值判断（notified 由 fireNotifications 内部去重并标记）
      const notifiedBefore = JSON.stringify(state.notified);
      await fireNotifications(state.rules, state.notified);
      if (JSON.stringify(state.notified) !== notifiedBefore) dirty = true;

      // 5. 到期拦截：更新 DNR 动态规则并重定向已打开的目标标签页
      const expired = state.rules
        .filter((r) => (r.usedMs || 0) >= limitSecondsOf(r) * 1000)
        .map((r) => r.domain);
      await syncBlockingRules(expired);
      await redirectOpenTabs(expired);

      // 6. 先写 session 与规则用量，最后写活动统计：活动写入失败不影响已保存的限时额度
      await chrome.storage.session.set({ segment: newSegment });
      if (dirty) {
        await chrome.storage.local.set({ rules: state.rules, notified: state.notified, date: state.date });
      }
      if (settled) {
        await FocusAnalytics.recordSegment(settled.segment, settled.elapsed, now, settled.effectiveStart);
      }
    });
  } catch (err) {
    // 计时异常必须留痕，否则表现为"不计时"且无从排查
    console.error('[专注助手] tick 结算失败:', err);
  }
}

// ---------- 初始化 ----------

async function registerDashboardMenu() {
  await chrome.contextMenus.remove(DASHBOARD_MENU_ID).catch(() => undefined);
  await chrome.contextMenus.create({
    id: DASHBOARD_MENU_ID,
    title: FocusI18n.t('openDashboard'),
    contexts: ['action'],
  });
}

async function initialize(reason) {
  try {
    if (reason === 'install' || reason === undefined) {
      const raw = await chrome.storage.local.get('rules');
      if (raw.rules === undefined) {
        await chrome.storage.local.set({
          rules: DEFAULT_RULES.map((r) => ({ domain: r.domain, limitMinutes: r.limitMinutes, usedMs: 0 })),
          date: localDateString(),
          notified: {},
        });
      }
    }
    if (reason === 'install' || reason === 'update') {
      await registerDashboardMenu();
    }
    // alarm 已存在时不能重复 create，否则每次 SW 唤醒都会重置计时
    const existing = await chrome.alarms.get(ALARM_NAME);
    if (!existing) {
      await chrome.alarms.create(ALARM_NAME, { periodInMinutes: ALARM_PERIOD_MINUTES });
    }
    // 浏览器重启后 onFocusChanged 不会补发，用 getLastFocused 恢复焦点窗口
    const current = await chrome.storage.session.get(['focusWindowId']);
    if (current.focusWindowId === undefined) {
      let windowId = chrome.windows.WINDOW_ID_NONE;
      try {
        const win = await chrome.windows.getLastFocused();
        if (win && win.focused) windowId = win.id;
      } catch (err) {
        // 当前没有任何 Chrome 窗口
      }
      await chrome.storage.session.set({ focusWindowId: windowId });
    }
    await tick();
  } catch (err) {
    // 初始化失败不阻塞后续事件驱动，但必须留痕
    console.error('[专注助手] 初始化失败:', err);
  }
}

// ---------- 消息处理（popup） ----------

// 清历史固定顺序：先 LLM_LOCK_NAME（挡住在途分析保存），再 LOCK_NAME。
// 只清 activity 与最近分析，保留规则与 LLM 配置。
async function clearAnalyticsData() {
  await navigator.locks.request(LLM_LOCK_NAME, async () => {
    await navigator.locks.request(LOCK_NAME, async () => {
      await FocusAnalytics.clearAll();
      await chrome.storage.local.set({ latestAnalysis: null });
    });
  });
}

// 规则变更与 tick 共用同一把锁串行执行，避免读-改-写相互覆盖。
// 锁内只做状态读写；tick 必须在锁外调用（Web Locks 同一锁不可重入，锁内调会死锁）。
async function mutateRules(mutator) {
  await navigator.locks.request(LOCK_NAME, async () => {
    const state = await loadState();
    await mutator(state);
    await chrome.storage.local.set({ rules: state.rules, notified: state.notified });
  });
  await tick();
  return { ok: true, state: await buildUiState() };
}

async function handleMessage(msg) {
  if (!msg || typeof msg.type !== 'string') throw new Error(FocusI18n.t('invalidRequest'));
  switch (msg.type) {
    case 'getState': {
      await tick();
      return { ok: true, state: await buildUiState() };
    }
    case 'addRule': {
      const domain = normalizeDomain(msg.domain);
      if (!domain) throw new Error(FocusI18n.t('invalidDomain'));
      const limitSeconds = readLimitSeconds(msg);
      if (limitSeconds === null) throw new Error(limitErrorText(msg));
      return mutateRules((state) => {
        if (state.rules.some((r) => r.domain === domain)) throw new Error(FocusI18n.t('ruleExists', domain));
        state.rules.push({ domain, limitSeconds, limitMinutes: Math.ceil(limitSeconds / 60), usedMs: 0 });
      });
    }
    case 'updateRule': {
      const domain = normalizeDomain(msg.domain);
      if (!domain) throw new Error(FocusI18n.t('invalidParams'));
      const limitSeconds = readLimitSeconds(msg);
      if (limitSeconds === null) throw new Error(limitErrorText(msg));
      return mutateRules((state) => {
        const rule = state.rules.find((r) => r.domain === domain);
        if (!rule) throw new Error(FocusI18n.t('ruleNotFound'));
        rule.limitSeconds = limitSeconds;
        rule.limitMinutes = Math.ceil(limitSeconds / 60);
      });
    }
    case 'removeRule': {
      const domain = normalizeDomain(msg.domain);
      if (!domain) throw new Error(FocusI18n.t('invalidParams'));
      return mutateRules((state) => {
        const next = state.rules.filter((r) => r.domain !== domain);
        if (next.length === state.rules.length) throw new Error(FocusI18n.t('ruleNotFound'));
        state.rules = next;
        delete state.notified[domain];
      });
    }
    case 'getDashboardData': {
      await tick();
      // tick 返回时锁已释放；读取在同一把 LOCK_NAME 内做，避免与 recordSegment 并发读写。
      // popup 仍传旧的 rangeDays:1，range 缺省时退回它；明细列表改用 getActivityPage 后传 includeActivities:false
      const data = await navigator.locks.request(LOCK_NAME, () =>
        FocusAnalytics.getDashboard(msg.range ?? msg.rangeDays, {
          summaryOnly: Boolean(msg.summaryOnly),
          includeActivities: msg.includeActivities,
        })
      );
      return { ok: true, data };
    }
    case 'getActivityPage': {
      // 结算由 getDashboardData/loadDashboard 负责；筛选分页只读日分桶，仍走同一把锁串行
      const data = await navigator.locks.request(LOCK_NAME, () =>
        FocusAnalytics.getActivityPage(msg.range ?? msg.rangeDays, {
          search: msg.search,
          domain: msg.domain,
          category: msg.category,
          sort: msg.sort,
          page: msg.page,
        })
      );
      return { ok: true, data };
    }
    case 'clearAnalytics':
      await clearAnalyticsData();
      return { ok: true };
    case 'getLlmConfig':
      return { ok: true, config: await FocusLlm.getConfig() };
    case 'saveLlmConfig':
      return { ok: true, config: await FocusLlm.saveConfig(msg) };
    case 'clearLlmApiKey':
      return { ok: true, config: await FocusLlm.clearApiKey() };
    case 'testLlmConnection': {
      const message = await FocusLlm.testConnection();
      return { ok: true, message };
    }
    case 'getLatestAnalysis':
      return { ok: true, analysis: await FocusLlm.getLatestAnalysis() };
    case 'analyzeBrowsing': {
      const analysis = await FocusLlm.analyze();
      return { ok: true, analysis };
    }
    case 'getPageStatus': {
      if (typeof msg.url !== 'string' || !msg.url.trim()) throw new Error(FocusI18n.t('invalidParams'));
      let hostname = '';
      try {
        const u = new URL(msg.url);
        if (u.protocol !== 'http:' && u.protocol !== 'https:') throw new Error(FocusI18n.t('httpOnly'));
        hostname = u.hostname.toLowerCase();
      } catch (err) {
        throw new Error(err && err.message ? err.message : FocusI18n.t('invalidUrl'));
      }
      await tick();
      const state = await loadState();
      const session = await chrome.storage.session.get(['segment']);
      const rule = state.rules.find((r) => domainMatches(hostname, r.domain)) || null;
      if (!rule) return { ok: true, rule: null, isCounting: false };
      const limitMs = limitSecondsOf(rule) * 1000;
      const usedMs = Math.min(rule.usedMs || 0, limitMs);
      return {
        ok: true,
        rule: {
          domain: rule.domain,
          remainingMs: Math.max(0, limitMs - usedMs),
          expired: usedMs >= limitMs,
        },
        isCounting: Boolean(session.segment) && segmentRuleDomain(session.segment) === rule.domain,
      };
    }
    default:
      throw new Error(FocusI18n.t('unknownCommand'));
  }
}

// ---------- 事件全部汇入 tick ----------

chrome.tabs.onActivated.addListener(() => {
  tick();
});
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  // title 变化（同站换页/SPA 改标题）也要触发结算与活动切换
  if (changeInfo.url || changeInfo.title || changeInfo.status === 'complete') tick();
});
chrome.windows.onFocusChanged.addListener((windowId) => {
  (async () => {
    try {
      await chrome.storage.session.set({ focusWindowId: windowId });
    } finally {
      tick();
    }
  })();
});
chrome.idle.onStateChanged.addListener(() => {
  tick();
});
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM_NAME) tick();
});
chrome.runtime.onStartup.addListener(() => {
  initialize('startup');
});
chrome.runtime.onInstalled.addListener((details) => {
  initialize(details.reason);
});
chrome.contextMenus.onClicked.addListener((info) => {
  if (info.menuItemId !== DASHBOARD_MENU_ID) return;
  (async () => {
    try {
      await chrome.tabs.create({ url: chrome.runtime.getURL('dashboard.html'), active: true });
    } catch (err) {
      console.error('[专注助手] 打开详细统计失败:', err);
    }
  })();
});
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    try {
      sendResponse(await handleMessage(msg));
    } catch (err) {
      sendResponse({ ok: false, error: err && err.message ? err.message : String(err) });
    }
  })();
  return true; // 异步响应
});

initialize();
